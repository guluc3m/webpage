===============================
Package contents
=============================== 

- com_feederator.zip
  Feederator component

- Joomla 1.0.xx files/fpod_bot.zip
  Feederator Podcast mambot, for Joomla 1.0.xx native only  

- Joomla 1.0.xx files/optional hack/joomla_1.0.15_corefiles_modified.zip
  Modified core file(s) of Joomla 1.0.15 to enable keywords filtering hack

- Joomla 1.0.xx files/optional hack/readme - Joomla 1.0.15.txt
  Instructions on how to enable the hack

- Joomla 1.5.xx legacy mode files/fpod_plugin.zip
  Feederator Podcast mambot, for Joomla 1.5.xx legacy mode only

- Joomla 1.5.xx legacy mode files/optional hack/joomla_1.5.3_corefiles_modified.zip
  Modified core file(s) of Joomla 1.5.3 to enable keywords filtering hack

- Joomla 1.5.xx legacy mode files/optional hack/readme - Joomla 1.5.3 in legacy mode.txt
  Instructions on how to enable the hack

===============================
How to update
=============================== 

You can update your current Feederator version to the most recent one by copying the files from
update.zip to the folder with your Joomla website. After the files have been copied, please log in
to the backend of Feederator and click "Update Classes" link in the main menu.