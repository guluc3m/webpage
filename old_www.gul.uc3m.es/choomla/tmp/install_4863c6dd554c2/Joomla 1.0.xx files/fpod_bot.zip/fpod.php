<?php

/**
* Feederator Podcasts Bot
* @version 1.0
* @copyright (c) 2007, Recly Interactive, www.recly.com
* @license GNU/GPL
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'feederator_display' );

require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/getid3/getid3.php' );
require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_RSS/Recly_RSSParser.php' );
require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/common/GlobalVariables.php' );
require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_HTML/Recly_Paginator.php');
require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_HTML/Recly_Toolbar.php' );

# Savant Class
require_once( $GLOBALS['mosConfig_absolute_path'].'/components/Recly/Savant2.php');

$arrayOfElements = array();
$feederatorPodcastsCounter = 0;
$feederatorPodcastsImage = '';

function fpod_getParams() {
	global $database, $_MAMBOTS;

	if ( !isset($_MAMBOTS->_content_mambot_params['fpod']) ) {
		// load mambot params info
		$query = "SELECT params, published"
		. "\n FROM #__mambots"
		. "\n WHERE element = 'fpod'"
		. "\n AND folder = 'content'"
		;
		$database->setQuery( $query );
		$database->loadObject($mambot);

		// save query to class variable
		$_MAMBOTS->_content_mambot_params['fpod'] = $mambot;
	}
	
	//echo "mambot=";print_r($mambot);echo "<hr>";

	$mambot = $_MAMBOTS->_content_mambot_params['fpod'];

 	$botParams = new mosParameters( $mambot->params );
	return $botParams;
}


function feederator_display( $published, &$row, &$params, $page=0 ) {
   
	// define the regular expression for the bot
	$regex = "#{fpod}(.*?){/fpod}#s";

	if (!$published) {

		$row->text = preg_replace( $regex, '', $row->text );
		return;
	}

	// perform the replacement
	$row->text = preg_replace_callback( $regex, 'feederator_replacer', $row->text );
	
	$podcastImage = '';
	//if ()
	//$row->text = str_repeat('{americast_image}', <img=)

	return true;
}

function feederator_replacer( &$matches ) {
       
    global $_REQUEST, $mosConfig_absolute_path;
	$thisParams = explode("|",$matches[1]);
	
	$botParams = fpod_getParams();

	$url = trim($thisParams[0]);
	$isUrl = strpos($url, 'http://');	  	

	
	if ($isUrl === false) {	  
    	$itemExists = $url;                   	   	
	} else {
    	$query = "SELECT Id FROM #__fdr_feeds WHERE url='$url' LIMIT 1";
    	$GLOBALS['database']->setQuery( $query );
    	$itemExists = $GLOBALS['database']->loadResult(); 
    }
    
    	if ($itemExists>0) {
    	       $url = $GLOBALS['mosConfig_live_site'].'/index.php?option=com_feederator&task=generateRSS&id='.intval($itemExists);  
               $page = mosGetParam($_REQUEST, 'page'.$itemExists, 1);
               $limit = mosGetParam($_REQUEST, 'limit'.$itemExists, ($botParams->def( 'number_of_items' ) != '') ? $botParams->def( 'number_of_items' ) : 10);	
               $limitstart = mosGetParam($_REQUEST, 'limitstart'.$itemExists, 0);	  	         
    	} else {
               $page = mosGetParam($_REQUEST, 'page', 1);
               $limit = mosGetParam($_REQUEST, 'limit', ($botParams->def( 'number_of_items' ) != '') ? $botParams->def( 'number_of_items' ) : 10);	
               $limitstart = mosGetParam($_REQUEST, 'limitstart', 0);	    	     	    
    	}      
    

           
	$parser = new Recly_RSSParser();
	$parser->parseURL($url); 
	
	
	//$limit = ($botParams->def( 'number_of_items' ) != '') ? $botParams->def( 'number_of_items' ) : 10;
    
  
    $pageNav = new Recly_Paginator( count($parser->items), $limitstart, $limit );
    
    if ($itemExists>0) {
        $pageNav->setCustomSuffix ($itemExists);
    }
    
$savantToolbarConf = array (
		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/components/com_feederator/templates/toolbar/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'template_URL' => $GLOBALS['mosConfig_live_site'] . "/components/com_feederator/templates/toolbar/"
);   

   $toolbar = new Recly_Toolbar('adminForm', $savantToolbarConf);
  
    $toolbar->enableStyles();    
    
$savantConf = array (
		'template_path' => $GLOBALS['mosConfig_absolute_path']."/components/com_feederator/templates/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'].'/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'].'/components/Recly/Savant2/'
);

$sociotagInstalled = false;
if (file_exists( $mosConfig_absolute_path .'/mambots/content/sociotag.php' )) {
    require_once($mosConfig_absolute_path . '/mambots/content/sociotag.php' );
    $sociotagInstalled = true;
}

    $savant = new Savant2($savantConf);
    $savant->assign('arrayOfElements', $parser->items);
    $savant->assign('page', 1);
    $savant->assign('pageNav', $pageNav);
    $savant->assign('isUrl', $isUrl);
    $savant->assign('itemExists', $itemExists);
    $savant->assign('config', new Recly_GlobalVariables('fdr_vars'));
    $savant->assign('sociotagInstalled', $sociotagInstalled);
    //$savant->assign('sociotagInstalled', $sociotagInstalled);
    $text = $savant->fetch('podcasts/main.tpl.php');

    return $text;
}


?>