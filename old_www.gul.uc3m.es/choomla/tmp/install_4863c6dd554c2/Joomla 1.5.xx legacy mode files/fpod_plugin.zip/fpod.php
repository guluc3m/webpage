<?php

/**
* Feederator Podcasts Bot
* @version 1.0 for Joomla 1.5 Legacy mode
* @copyright (c) 2008, Recly Interactive, www.recly.com
* @license GNU/GPL
*/

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

require_once( JPATH_SITE.DS. 'components/Recly/getid3/getid3.php' );
require_once( JPATH_SITE.DS. 'components/Recly/Recly_RSS/Recly_RSSParser.php' );
require_once( JPATH_SITE.DS. 'components/Recly/common/GlobalVariables.php' );
require_once( JPATH_SITE.DS. 'components/Recly/common/String.php' );
require_once( JPATH_SITE.DS. 'components/Recly/Recly_HTML/Recly_Paginator.php');
require_once( JPATH_SITE.DS. 'components/Recly/Recly_HTML/Recly_Toolbar.php' );

# Savant Class
require_once( JPATH_SITE.DS. 'components/Recly/Savant2.php');

$mainframe->registerEvent( 'onPrepareContent', 'fpod_preparecontent' );

class pluginFpodHelper {

    var $plugin = null;
    var $pluginParams = null;
    var $arrayOfElements = array();
    var $feederatorPodcastsCounter = 0;
    var $feederatorPodcastsImage = '';

    function pluginFpodHelper() {
        
    // Get Plugin info
	$this->plugin =& JPluginHelper::getPlugin('content', 'fpod');
	
	$this->pluginParams = new JParameter( $this->plugin->params );    
        
    }
}


function fpod_preparecontent( &$row, &$params, $page=0 ) {

    if (isset($row->text)) {
     	// simple performance check to determine whether bot should process further
    	if ( strpos( $row->text, 'fpod' ) === false ) {
    		return true;
    	} 
    	// define the regular expression for the bot
    	$regex = "#{fpod}(.*?){/fpod}#s";   
    
    	// perform the replacement
    	$row->text = preg_replace_callback( $regex, 'fpod_replacer', $row->text );
	
    }


	return true;
}




function fpod_replacer( &$matches ) {
       
    global $mainframe;
    $db = & JFactory::getDBO();
    $fpod = new pluginFpodHelper();
    
	$thisParams = explode("|",$matches[1]);

	$url = trim($thisParams[0]);
	$isUrl = strpos($url, 'http://');	  	

	
	if ($isUrl === false) {	  
    	$itemExists = $url;                   	   	
	} else {
    	$query = "SELECT Id FROM #__fdr_feeds WHERE url='$url' LIMIT 1";
    	$db->setQuery( $query );
    	$itemExists = $db->loadResult(); 
    }
    
    	if ($itemExists>0) {
    	       $url = $mainframe->getBasePath().'/index.php?option=com_feederator&task=generateRSS&id='.intval($itemExists);  
               $page = JRequest::getInt( 'page'.$itemExists, 1 );
               $limit = JRequest::getInt( 'limit'.$itemExists, ($fpod->pluginParams->get( 'number_of_items' ) != '') ? $fpod->pluginParams->get( 'number_of_items' ) : 10);	
               $limitstart = JRequest::getInt( 'limitstart'.$itemExists, 0 ); 	         
    	} else {
               $page = JRequest::getInt( 'page', 1 );
               $limit = JRequest::getInt( 'limit', ($fpod->pluginParams->get( 'number_of_items' ) != '') ? $fpod->pluginParams->get( 'number_of_items' ) : 10);	
               $limitstart = JRequest::getInt( 'limitstart', 0 ); 	             	     	    
    	}      
         
	$parser = new Recly_RSSParser();
	$parser->parseURL($url); 
  
    $pageNav = new Recly_Paginator( count($parser->items), $limitstart, $limit );
    
    if ($itemExists>0) {
        $pageNav->setCustomSuffix ($itemExists);
    }
    
$savantToolbarConf = array (
		'template_path' => JPATH_SITE.DS. 'components/com_feederator/templates/toolbar/',
		'plugin_path' => JPATH_SITE.DS. 'components/Recly/Savant2/',
		'filter_path' => JPATH_SITE.DS. 'components/Recly/Savant2/',
		'template_URL' => $mainframe->getBasePath().'/components/com_feederator/templates/toolbar/'
);   

   $toolbar = new Recly_Toolbar('adminForm', $savantToolbarConf);
   $toolbar->enableStyles();    
    
$savantConf = array (
		'template_path' => JPATH_SITE.DS. 'components/com_feederator/templates/',
		'plugin_path' => JPATH_SITE.DS. 'components/Recly/Savant2/',
		'filter_path' => JPATH_SITE.DS. 'components/Recly/Savant2/'
);

$sociotagInstalled = false;
if (file_exists( JPATH_SITE.DS. 'plugins/content/sociotag.php' )) {
    require_once(JPATH_SITE.DS. 'plugins/content/sociotag.php' );
    $sociotagInstalled = true;
}


    $savant = new Savant2($savantConf);
    $savant->assign('arrayOfElements', $parser->items);
    $savant->assign('page', 1);
    $savant->assign('pageNav', $pageNav);
    $savant->assign('isUrl', $isUrl);
    $savant->assign('itemExists', $itemExists);
    $savant->assign('config', new Recly_GlobalVariables('fdr_vars'));
    $savant->assign('sociotagInstalled', $sociotagInstalled);
    $savant->assign('mainframe', $mainframe);
    $text = $savant->fetch('podcasts/main_joomla1.5.tpl.php');
        
    return $text;
}


?>