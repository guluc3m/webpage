<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

   class Recly_Config {
      var $_data;
      var $_name;
      var $_filename;
      var $_path;

      function Recly_Config($path = '/components/Recly/') {
         $this->_data = array(); 
         $this->_path = $path;      
      }


      function get($key) {
         return isset($this->_data[$key]) ? 
            $this->_data[$key] : NULL;
      }

      function set($key, $value) {

            $this->_data[$key] = $value;
            $this->_save();

      }
      
      function setPath ($path = '/components/Recly/') {
         $this->_path = $path;           
      }
      
      function exists () {
          $result = false;
          if (file_exists($this->_filename)) {
            $result = false;   
          }
          return $result;
      }
     
      function read($name = '') {
         $result = false; 
         if ($name != '') {
            $this->_name = $name;
            $this->_filename = $GLOBALS['mosConfig_absolute_path'].$this->_path.$this->_name.".ini"; 
         }      
         if (file_exists($this->_filename)) {
            $src = join("", file($this->_filename));
            $this->_data = unserialize(preg_replace('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'", $src));
            $result = true;
         }
         return $result;
      }

      function _save() {
         $result = false;
         if (isset($this->_data) && is_array($this->_data)) {
            $src = serialize($this->_data);
            
            $handler = fopen($this->_filename, "w");           
            
            if ($handler) {
               fwrite($handler, $src);
               fclose($handler);
               $result = true;
            }
         }
         return $result;
      }
      
    function install($classes, $componentName, $name) {
        $mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path'];
        
    	if(!class_exists('PclZip')){
    	  include_once($mosConfig_absolute_path. "/administrator/includes/pcl/pclzip.lib.php");
    	}
    
    	$archive = new PclZip($mosConfig_absolute_path."/administrator/components/$componentName/Recly.zip");
    	$archive->extract(PCLZIP_OPT_PATH, $mosConfig_absolute_path."/administrator/components/$componentName/");     
        
        $result = '<fieldset>';    
    
        $hadProblems = false;   
    		 
    
    if(is_writable($mosConfig_absolute_path . "/components/")) {    
        
          if(!file_exists($mosConfig_absolute_path . '/components/Recly/')){
             if(!mkdir($mosConfig_absolute_path . '/components/Recly/')) {
                 $result .= "<font color=red>Couldn't create ".$mosConfig_absolute_path . '/components/Recly/'. ", you may need to create it manually</font><br />";
                 $hadProblems = true;
             } else {
                 
                    createIndexHTML($mosConfig_absolute_path . '/components/Recly/'); 
             
             } 
          }
          
          $currentDir = '';
    	  foreach($classes AS $class) {
        	  if(!file_exists($mosConfig_absolute_path . '/components/Recly/'.$class[1])) {
        	    $successNumber = 0;  
        	    if(mkdir($mosConfig_absolute_path . '/components/Recly/'.$class[1])) {
        	        $successNumber++;
    
        	        if (copyFile ($class, '.php')) {
        	           $successNumber++;
        	        }
        	        
        	        if ($class[2] && copyFile ($class, '.ini')) {
        	           $successNumber++;
        	        }
        	               	        
                    createIndexHTML($mosConfig_absolute_path . '/components/Recly/'.$class[1]); 
    
      	        
        	    }
        	    if (($successNumber == 3 && $class[2]) || ($successNumber == 2 && !$class[2])) { 	           	        
        	    	$result .= "<img src='".$GLOBALS['mosConfig_live_site']."/components/$componentName/images/tick.gif'>&nbsp;<font color=\"green\" style=\"font-family: courier, arial;font-size:8px; \">".$class[0] ." has been successfully added</font><br />";
        		} else {
        		    $hadProblems = true;
        			$result .= "<img src='".$GLOBALS['mosConfig_live_site']."/components/$componentName/images/cross.gif'>&nbsp;<font color=\"red\" style=\"font-family: courier, arial;font-size:8px; \">Couldn't create ".$mosConfig_absolute_path . '/components/Recly/'.$class[1].'/'.$class[0].'.php'. ", you may need to create it manually!</font><br />";
        		}
        	  }  else {
        	    $exists = true; 
        	    if ($class[2] && (!file_exists($mosConfig_absolute_path . '/components/Recly/'.$class[1].'/'.$class[0].'.php') ||
        	       !file_exists($mosConfig_absolute_path . '/components/Recly/'.$class[1].'/'.$class[0].'.ini'))) {
        	       $exists = false;   
        	    } 
            	    
            	    $outdatedVersion = false;
            	    $namesDifferent = false;
            	    if ($class[2] == 1) {
            	        
                	    $this->setPath();  
                	    $this->read($class[1].'/'.$class[0]); 
                	    $currentName = $this->get('name'); 
                	    $currentVersion = explode('.', $this->get('version'));            	        
            	        
                	    $this->setPath('/administrator/components/'.$componentName.'/Recly/');               	    
                	    $this->read($class[1].'/'.$class[0]); 
                	    $latestName = $this->get('name'); 
                	    $latestVersion = explode('.', $this->get('version')); 
                	    
                	    if (($latestVersion[0] == $currentVersion[0] && $latestVersion[1] == $currentVersion[1] && $latestVersion[2] > $currentVersion[2]) ||
                	       ($latestVersion[0] == $currentVersion[0] && $latestVersion[1] > $currentVersion[1]) ||
                	       ($latestVersion[0] > $currentVersion[0])) {
                    	       $outdatedVersion = true;    
                	       }
                	    if ($currentName != $latestName) $namesDifferent = true;  
                	    
            	    }
            	    
        	        $successNumber = 0;   
        	                	     
            	    if ( $namesDifferent ||
                	     $outdatedVersion ||
                	     (!$exists && $class[2]) ||
                	     !$class[2]) {
        	               	           
                	        if (copyFile ($class, '.php')) {
                	           $successNumber++;
                	        }
            	        if ($class[2] && copyFile ($class, '.ini')) {
                	           $successNumber++;
                	        }  
            	        $stateSuccess = ($exists) ? "updated" : "added";
            	        $stateFailure = ($exists) ? "update" : "add";
    
                	    if (($successNumber == 2 && $class[2]) || ($successNumber == 1 && !$class[2])) { 	           	        
                	    	$result .= "<img src='".$GLOBALS['mosConfig_live_site']."/components/$componentName/images/tick.gif'>&nbsp;<font color=green style=\"font-family: courier, arial;font-size:8px; \">".$class[0] ." has been successfully $stateSuccess</font><br />";
                    		} else {
                    		    $hadProblems = true;
                    			$result .= "<img src='".$GLOBALS['mosConfig_live_site']."/components/$componentName/images/cross.gif'>&nbsp;<font color=\"red\" style=\"font-family: courier, arial;font-size:8px; \">Couldn't $stateFailure ".$mosConfig_absolute_path . '/components/Recly/'.$class[1].'/'.$class[0].'.php'. ", you may need to $stateFailure it manually!</font><br />";
        	         }
        	    
        	    }
        	  }
    	  }	  
    } else {
        $hadProblems = true;
    	$result .= "<img src='".$GLOBALS['mosConfig_live_site']."/components/$componentName/images/cross.gif'>&nbsp;<font color=\"red\" style=\"font-family: courier, arial;font-size:8px; \">".$mosConfig_absolute_path . "/components/ is not writable!</font><br /><font color=\"red\">  Manually do the following:<br />";
        $i = 1;
    	foreach($classes AS $class) {
    	   $result .= "$i. create ".$mosConfig_absolute_path . '/components/Recly/'.$class[1] . " directory and chmod it to 777<br />";
    	   $i++;
        }
        $result .= "</font><br />";
    }
    
    if ($hadProblems) {
     	$result .= "<br /><font color='orange'>WARNING &nbsp; , $name has encountered some minor problems during the install. Please check the log above and try again!</font>";
    	$result .= "<p /><a href=\"index2.php?option=$componentName&task=install\">Try again!</a>";     
    } else {
     	$result .= "<br /><font color='green'>OK &nbsp; , $name Installed Successfully!</font></fieldset>";
    	$result .= "<p /><a href=\"index2.php?option=$componentName\">Run , $name now!</a>";   
    }
    $result .= "</fieldset>";
    
    return $result;
        
    }
      

   }
?>