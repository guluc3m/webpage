<?php
/**
 * 
 * @version $Id: admin.feederator.php,v 1.2 2006/10/29 15:16:12 atnika $
 * @package Feederator
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * This is free software
 * 
 **/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

// ensure user has access to this function
if (!($acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'all' ) | $acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'com_feederator' ))) {
	mosRedirect( 'index2.php', _NOT_AUTH );
}

require_once( $mosConfig_absolute_path . '/components/com_feederator/language/english.php');

$hide = mosGetParam($_REQUEST, 'hide', '0' );

switch ($task) {
    
    case 'install':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/install.feederator.php');
            echo com_install();
            $hide = 1;
    break; 
            
}

require_once( $mosConfig_absolute_path . '/components/Recly/common/String.php');
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_RSS/Recly_RSS.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_Toolbar.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/common/GlobalVariables.php');
require_once( $mosConfig_absolute_path . '/components/Recly/Savant2.php');
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_Paginator.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_HTML.php' );


$globalVariables = new Recly_GlobalVariables('fdr_vars');


if (file_exists( $mosConfig_absolute_path .'/includes/frontend.php' )) {
    require_once( $mosConfig_absolute_path .'/includes/frontend.php' );
}




$tempIdFromURL = mosGetParam($_REQUEST, 'id', '' );
if ($tempIdFromURL == '') {
	$id = mosGetParam( $_POST, 'cid', array(0) );
} else {
	$id = array( $tempIdFromURL );
} 

$feedType = mosGetParam($_REQUEST, 'feedType', '1' );

if ('new_feed_step2' == $task && $feedType == '1') {
    $task = 'add_internal';    
}

if ('new_feed_step2' == $task && $feedType == '2') {
    $task = 'add_external';    
}

if ('new_feed_step2' == $task && $feedType == '3') {
    $task = 'add_compilation';    
}

if (!$hide) {

?>
	<table cellpadding="3" cellspacing="0" border="0" width="100%">
	<tr>
		<td align="left" valign="top" width="160" height="0">
<?php  

$database->setQuery( "SELECT COUNT(*) FROM #__fdr_feeds");           		
$numberOfFeeds = $database->loadResult();

$savantConf = array (
		'template_path' => $mosConfig_absolute_path . "/administrator/components/com_feederator/templates/",
		'plugin_path' => $mosConfig_absolute_path . '/components/Recly/Savant2/',
		'filter_path' => $mosConfig_absolute_path . '/components/Recly/Savant2/'
);
$savant = new Savant2($savantConf);

$savant->assign('feederator_mode', $globalVariables->get('mode')); 
$savant->assign('numberOfFeeds', $numberOfFeeds);
$savant->display('dashboard.tpl.php'); 
}



   $toolbar = new Recly_Toolbar('adminForm', array (
		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/components/com_feederator/templates/toolbar/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'template_URL' => $GLOBALS['mosConfig_live_site'] . "/components/com_feederator/templates/toolbar/"
));

   $toolbar->enableStyles();

//echo "task=<pre>";print_r($task);echo "</pre><hr>";

//exit;

if (!$hide) {
?>
		</td>
		<td valign="top">
<?php
}

switch ($task) {
    
    case 'new_feed_step1':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/new.php');   
            break; 
    case 'add_internal':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/add_rss_internal.php');   
            break;  
            
    case 'install':
            
              
            break; 
                        
    case 'add_external':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/add_rss_external.php');   
            break;    
    case 'add_compilation':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/add_rss_compilation.php');   
            break;               
                       
                      
    case 'edit':
    
            if (is_array($id)) $id = $id[0];    

		    $row = new Recly_RSS( 'Id','#__fdr_' );
            $row->load( $id );
            
            if ($row->internal == '0') {
                require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/edit_rss_external.php');                 
            } else if ($row->internal == '1') {
                require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/edit_rss_internal.php');     
            } else if ($row->internal == '2') {
                require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/edit_rss_compilation.php');     
            }    
  
    break;
    
    case 'apply_tmsp':
    case 'save_tmsp':
    case 'publish_tmsp':
    case 'unpublish_tmsp':
    case 'delete_tmsp':
    case 'cancel_tmsp':    
    case 'manage_tmsp':

            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/tmsp/tmsp.php');
        break;  
        
    case 'edit_tmsp':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/tmsp/edit_tmsp.php');   
  
    break;           
    
    case 'new_tmsp':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/tmsp/add_tmsp.php');    
    break;       
        
   
    
    case 'settings':
    case 'applysettings':
    case 'savesettings':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/settings/settings.php');   
   
    break;     
    
    case 'about':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/about/about.php');
        break;      
     
         
    case 'parseFeed':
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/parse.php');
        break;    
    
    
    case 'parse':    
            
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/parseSelected.php');
        break;         
    case 'apply':
    case 'save':
    case 'publish':
    case 'unpublish':
    case 'delete':
    default:
            require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/rss/rss.php');
        break; 
}

if (!$hide) {

?>
		</td>
		</tr>
	</table>
	
<?php } ?>
