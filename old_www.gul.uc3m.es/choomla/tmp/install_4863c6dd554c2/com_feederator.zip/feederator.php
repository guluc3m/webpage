<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

// load feed creator class
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_RSS/feedcreator.php' );
//require_once( $mosConfig_absolute_path . '/components/Recly/common/WebVariables.php');
require_once( $mosConfig_absolute_path . '/components/Recly/common/String.php');
require_once( $mosConfig_absolute_path . '/components/Recly/Savant2.php');
require_once( $mosConfig_absolute_path . '/components/com_feederator/language/english.php');
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_RSS/Recly_RSS.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_Keywords/Recly_Keywords.php' );


$savantConf = array (
		'template_path' => $mosConfig_absolute_path . "/components/com_feederator/templates/",
		'plugin_path' => $mosConfig_absolute_path . '/components/Recly/Savant2/',
		'filter_path' => $mosConfig_absolute_path . '/components/Recly/Savant2/'
);

$id = mosGetParam($_REQUEST, 'id', '' );

switch ( $task ) {

	case 'search':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/search/search.php');
      break;      
      
	case 'createFeed':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/rss/add.php');
      break;   
      
	case 'list_feeds':
	case 'remove_feeds':
	case 'cancel':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/rss/main.php');
      break;         

	case 'edit_feed':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/rss/edit.php');
      break;             

	case 'save_feed':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/rss/save.php');
      break;            
    
      
	case 'confirm_tmsp':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/tmsp/confirm.php');
      break; 

    case 'subscribe_tmsp':  
	case 'unsubscribe_tmsp':
	    
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/tmsp/subscription.php');
      break; 
      
    case 'generateRSS':
        require_once($mosConfig_absolute_path . '/components/com_feederator/includes/rss/display.php');
    break;  
           
	case 'watch':
	case 'stop_watching':
	default:
	
            require_once($mosConfig_absolute_path . '/components/com_feederator/includes/rss/display.php');
           
		break;
}


?>