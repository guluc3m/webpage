<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once($mosConfig_absolute_path . '/components/Recly/common/GlobalVariables.php');
require_once($mosConfig_absolute_path . '/components/Recly/Recly_RSS/Recly_RSSParser.php' );
require_once($mosConfig_absolute_path . '/components/Recly/simplepie/simplepie.inc.php' );

$globalVariables = new Recly_GlobalVariables('fdr_vars');

//TODO: remove those
$arrayOfElements = array();
$feederatorPodcastsCounter = 0;
$feederatorPodcastsImage = '';

$searchTerm = mosGetParam($_REQUEST, 'searchword', null);
$backToSearchURL = sefRelToAbs('index.php?option=com_feederator&amp;task=search&amp;searchword='.$searchTerm);
$backToSearchButton = "[<a href=\"$backToSearchURL\">Back&gt;&gt;&gt;</a>]";

if ($id != '') {
    switch ( $task ) {
    
    	case 'generateRSS':
    			$feed = new Recly_RSS( 'Id','#__fdr_' );
		        $feed->load( $id ); 
		        
		        $use = mosGetParam($_REQUEST, 'use', null);
		          			        
        			if ($feed->published && $feed->internal == '1') {	       	             
        	             if ($use == 'widget') {
		                     widgetRSS( $feed, 'display' );	
        	             } else {
        	                 display( $feed );
        	             }  
        			} else if ($feed->published && $feed->internal == '0') {   		             
        	             if ($use == 'widget') {
		                     widgetRSS( $feed, 'rebrand' );	
        	             } else {
        	                 rebrand( $feed );
        	             }      		             
        			} else if ($feed->published && $feed->internal == '2') {
        	             if ($use == 'widget') {
		                     widgetRSS( $feed, 'compile' );	
        	             } else {
        	                 compile( $feed );
        	             } 
        			}
		        
    			    			
          break;      
          
    	case 'watch':
    	    if ($my->id!='') { 	        
    	        watch ($id, 1);
    	    } else {
    	        echo "In order to watch this feed you need to login. What does 'watching' mean? You would receive notices on your phone number any time this feed is updated. $backToSearchButton";   
    	    }
          break;  
           
    	case 'stop_watching':
    	    if ($my->id!='') {
    	        watch ($id, 0);
    	    } else {
    	        echo "Please log in first, and then disable watching this feed. $backToSearchButton";   
    	    }
          break;           
    }
}

function widgetRSS ($feed, $displayType = 'rebrand') {
    global $mosConfig_absolute_path, $_REQUEST, $mosConfig_live_site;
    
    $rssItems = new SimplePie();
    
    if ($displayType == 'display' || $displayType == 'compile') {
        $feed->url = $mosConfig_live_site."/index2.php?option=com_feederator&task=generateRSS&id=".$feed->Id;   
    }
    
    //echo "displayType=<pre>";print_r($displayType);echo "</pre><hr>";
    
    //exit;
    // Strip slashes if magic quotes is enabled (which automatically escapes certain characters)
    	if (get_magic_quotes_gpc())
    	{
    		//$feed->url = stripslashes(htmlentities($feed->url,ENT_QUOTES));
    		//$feed->url = htmlentities($feed->url,ENT_QUOTES);
    	}
    	
    //echo "feed->url=<pre>";print_r($feed->url);echo "</pre><hr>";
	
    
    $rssItems->feed_url($feed->url); 
    //$rssItems->item_xmlbase = 'http://www.jopa.com';
    $rssItems->enable_caching(true);
    $rssItems->cache_location($mosConfig_absolute_path .'/cache');
    $rssItems->init(); 
    
    $rssItems->handle_content_type();
    
   // echo "rssItems=<pre>";print_r($rssItems);echo "</pre><hr>";

    
   // if(!file_exists("cache"))mkdir("cache",0775); 
    
    $maxRssItems = mosGetParam($_REQUEST, 'maxRssItems', 5); // Maximum number of RSS news to show. 
    // Change the title of the Feed here by using the variable set in the backend.
    //if 	(isset($selfheader) { echo $selfheader."\n"; } else {		
    echo $rssItems->get_feed_title()."\n";	
    if (min($maxRssItems,$rssItems->get_item_quantity()) < 1) { 
    $damin = $rssItems->get_item_quantity(); 
    echo $damin . "\n";   // Number of news  
    } else { 
    echo min($maxRssItems,$rssItems->get_item_quantity())."\n";   // Number of news  
    }
    
    
    $max = $rssItems->get_item_quantity($maxRssItems);
    
    //echo "max=<pre>";print_r($max);echo "</pre><hr>";
    
    	echo $max;
        for ($x = 0; $x < $max; $x++) {
            $item = $rssItems->get_item($x);
            //echo "item=<pre>";print_r($item);echo "</pre><hr>";

    					echo "\n\n";
    					$title = $item->get_title();
    					$title = mb_convert_encoding($title,"HTML-ENTITIES","auto");
    					echo preg_replace("/[\r\n]/"," ",htmlentities($title,ENT_QUOTES,"UTF-8"))."##";   // Title
    					echo mosFormatDate( strtotime($item->get_date('j M Y')), _DATE_FORMAT_LC2 )."##";   // Date 
    					$description = strip_tags($item->get_description());
    					$description = substr(addslashes($description),0,150);
    					//$description = $item->get_description();					
    					$description = mb_convert_encoding($description,"HTML-ENTITIES","auto");
    					if ($description) { 
    					    echo preg_replace("/[\r\n]/"," ",htmlentities($description,ENT_QUOTES,"UTF-8"))."##";
    					   // echo preg_replace("/[\r\n]/"," ",$description)."##";
    					  //echo $description."[]";
    					 }
    					else { /*echo "NO FEED DESCRIPTION" . "##";*/ echo " " ."##";}   // Description 
    					echo preg_replace("/[\r\n]/"," ",$item->get_permalink())."##";   // Link 
    	}     
    
}

function watch ($id, $isWatching) {
       
    $backToSearchButton = $GLOBALS['backToSearchButton'];  
    
    $db = $GLOBALS['database'];
    $my = $GLOBALS['my'];
    
    $reclyRSS = new Recly_RSS('Id','#__fdr_');   
    $reclyRSS->load($id);
    
    	$query = "SELECT receive_notifications_confirmed FROM #__users WHERE id='".$my->id."'";
    	$db->setQuery( $query );
    	//echo $db->getQuery()."<hr>";
    	$isPhoneNumberConfirmed = $db->loadResult();
	
    if ($isWatching == '1') {	
    	if ($isPhoneNumberConfirmed && !$reclyRSS->isFeedWatchedByUser($id, $my->id)) {
        		$query = "INSERT INTO #__fdr_watched_feeds"
        		. "\n SET id_user = '$my->id', id_rss = '$id'"
        		;
        		$db->setQuery( $query );
        		//echo $db->getQuery()."<hr>";
        		$db->query();

        		echo "You have been successfully subscribed to receive notices whenever RSS Feed '$reclyRSS->name' is updated. $backToSearchButton";
        	    
    	} else {
    	    echo "Cannot start watching this feed as you haven't confirmed your phone number yet! $backToSearchButton";
    	}
    }
    
	if ($isWatching == '0') {
	    if($reclyRSS->isFeedWatchedByUser($id, $my->id)) {
    		$query = "DELETE FROM #__fdr_watched_feeds"
    		. "\n WHERE id_user = '$my->id' AND id_rss = '$id'"
    		;
    		$db->setQuery( $query );
        	if (!$db->query()) {
        		echo "<script> alert('".$db->getErrorMsg()."'); window.history.go(-1); </script>\n";
        	} else {
        		echo "You have been successfully unsubscribed from receiving notices on updates of '$reclyRSS->name' RSS Feed. $backToSearchButton";

        	}       	    
    	} else {
    	    echo "Cannot stop watching the feed, which have not yet been watched. $backToSearchButton";
    	}	
	}
	
    
}

function getItemsInternalRSS2 ($rows, $params, &$rss, $feed) {
        $mainframe = $GLOBALS['mainframe'];
        $mosConfig_live_site = $GLOBALS['mosConfig_live_site'];   
    
 		if (count($rows) && $params->published) {
			foreach ( $rows as $row ) {
				// title for particular item
				$item_title = htmlspecialchars( $row->title );
				$item_title = html_entity_decode( $item_title );
		
				$itemid = 0;
				if ($mainframe->getItemid( $row->id ) != 0) {
				    $itemid = $mainframe->getItemid( $row->id );
				} else {
				    if ($feed->itemid > 0) $itemid = $feed->itemid;  
				}
				// url link to article
				// & used instead of &amp; as this is converted by feed creator
		  		$item_link = sefRelToAbs('index.php?option=com_content&task=view&id='. $row->id .'&Itemid='. $itemid) ;
		
				// removes all formating from the intro text for the description text
				$item_description = ($row->show_full == 1) ? $row->introtext.$row->fulltext : $row->introtext;
				$item_description = mosHTML::cleanText( $item_description );
				$item_description = html_entity_decode( $item_description );
				if ( !$feed->show_full && $feed->limit_text>0 ) {			    
						// limits description text to x words
						$item_description_array = split( ' ', $item_description );
						$count = count( $item_description_array );
						if ( $count > $feed->limit_text ) {
							$item_description = '';
							for ( $a = 0; $a < $feed->limit_text; $a++ ) {
								$item_description .= $item_description_array[$a]. ' ';
							}
							$item_description = trim( $item_description );
							$item_description .= '...';
						}
					
				}
		
				// load individual item creator class
				$item = new FeedItem();
				// item info
				$item->title 		= $item_title;
				$item->link 		= $item_link;
				$item->description 	= $item_description;
				$item->source 		= $params->link;
				$item->date			= date( 'r', $row->created_ts );
		
				// loads item info into rss array
				$rss->addItem( $item );
			}
		}
  
         
}


function getItemsCompiled ($rows, $params, &$rss) {
        $mainframe = $GLOBALS['mainframe'];
        $mosConfig_live_site = $GLOBALS['mosConfig_live_site'];   

	
		if (count($rows) && $params->published) {
		    
		$lastBuildDate = 0;
		$lastBuildDateString = '';
		$lastBuildDateName = '';
		foreach ($rows as $rssItem) { 
		       
		// load individual item creator class
		$item = new FeedItem();
		$enclosuresCounter = 0;
			  
		 foreach ($rssItem as $k=>$v) {
		     
		    // echo "k=";print_r($k);echo ", v=";print_r($v);echo "<hr>"; 
		     $k = strtoupper($k);    
		    
                 switch ($k) {
                 	case 'TITLE':
            				$item_title = htmlspecialchars( $v );
            				$item->title = html_entity_decode( $item_title );
                 		
                 		break;
                 		
                 	case 'DESCRIPTION':
            
            				// removes all formating from the intro text for the description text
            				$item_description = $v;
           		
                 		break;     		
                 		
                  	case 'LINK':
            				//$item_link = $v;
            		  		$item->link = $v;               		
                 		break;            

                  	case 'PUBDATE':

            				$item->date = $v;
            				$itemDate = strtotime($v);
            				if ($itemDate>$lastBuildDate) {
            				    $lastBuildDate = $itemDate;
 
           				}
            				
             				              		
                 		break; 
                 		
                  	case 'GUID':
            				$item->guid = $v;                 		
                 		break;                  		

                  	case 'CATEGORY':
            				$item->category = $v;                 		
                 		break;                  		                		
                 		
                  	case 'ENCLOSURE_URL':
            				$item->enclosures[$enclosuresCounter]['url'] = $v;                 		
                 		break;
                 		                   		  
                  	case 'ENCLOSURE_LENGTH':
            				$item->enclosures[$enclosuresCounter]['length'] = $v;                 		
                 		break;                  		
                 		  
                  	case 'ENCLOSURE_TYPE':
            				$item->enclosures[$enclosuresCounter]['type'] = $v;                 		
                 		break;                  		
                 		
                   	case 'ITUNES_AUTHOR':
            				$item->itunes_author = $v;                 		
                 		break; 
                   	case 'ITUNES_SUBTITLE':
            				$item->itunes_subtitle = $v;                 		
                 		break;                  		                		
                   	case 'ITUNES_SUMMARY':
            				$item->itunes_summary = $v;                 		
                 		break;                   		
                   	case 'ITUNES_DURATION':
            				$item->itunes_duration = $v;                 		
                 		break;                  		
                   	case 'ITUNES_KEYWORDS':
            				$item->itunes_keywords = $v;                 		
                 		break; 
                 		                 		
                 	default:
               	
                 		break;
                 }
		    }
		    
		    
		    if ($item->enclosures[$enclosuresCounter]['length'] != '') {
		          $enclosuresCounter++;    
		    }
		     
				$item->description 	= $item_description;
				$item->source 		= $params->link;
				
				$rss->addItem( $item ); 
		}	    
    }
}

function display ($feed) {
    
        $db = $GLOBALS['database'];
        $mainframe = $GLOBALS['mainframe'];
        $mosConfig_live_site = $GLOBALS['mosConfig_live_site'];

		$mosConfig_offset = $GLOBALS['mosConfig_offset'];
		$mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path'];
		
		$showFeed = true;
		
		$params = getParameters($feed);

		// set filename for live bookmarks feed
		if ( !$showFeed & $params->live_bookmark ) {
			// standard bookmark filename
			$params->file = $mosConfig_absolute_path .'/cache/'. $params->live_bookmark . "_" . $feed->Id;
		} else {
		// set filename for rss feeds
			$params->file = strtolower( str_replace( '.', '', $params->feed ) );
			$params->file = $mosConfig_absolute_path .'/cache/'. $params->file. "_" .$feed->Id .'.xml';
		}
	
		// load feed creator class
		$rss 	= new UniversalFeedCreator();
		// load image creator class
		$image 	= new FeedImage();
	
		// loads cache file
		if ( $showFeed && $params->cache ) {
			$rss->useCached( $params->feed, $params->file, $params->cache_time );
		}

		$rss->title 			= $params->title;
		$rss->description 		= $params->description;
		$rss->link 				= $params->link;
		$rss->syndicationURL 	= $params->link;
		$rss->cssStyleSheet 	= NULL;
		$rss->encoding 			= $params->encoding;

		if ( isset($params->image) ) {
			$image->url 		= $params->image;
			$image->link 		= $params->link;
			$image->title 		= $params->image_alt;
			$image->description	= $params->description;
			// loads image info into rss array
			$rss->image 		= $image;
		}

		$rows = getData($params, $feed);	

		getItemsInternalRSS2 ($rows, $params, $rss, $feed);
		
		//save feed file
		$rss->saveFeed( $params->feed, $params->file, $showFeed );

    
}

function rebrand ($feed) {
    
        //$days = array("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");

    
        $db = $GLOBALS['database'];
        $mainframe = $GLOBALS['mainframe'];
        $mosConfig_live_site = $GLOBALS['mosConfig_live_site'];

		$mosConfig_offset = $GLOBALS['mosConfig_offset'];
		$mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path'];
		
		$showFeed = true;
		
		$parser = new Recly_RSSParser(); 
		
		$parser->parseURL($feed->url);
		
		
		$params = getParameters($feed);

		// set filename for live bookmarks feed
		if ( !$showFeed & $params->live_bookmark ) {
			// standard bookmark filename
			$params->file = $mosConfig_absolute_path .'/cache/'. $params->live_bookmark . "_" . $feed->Id;
		} else {
		// set filename for rss feeds
			$params->file = strtolower( str_replace( '.', '', $params->feed ) );
			$params->file = $mosConfig_absolute_path .'/cache/'. $params->file. "_" .$feed->Id .'.xml';
		}
	
		// load feed creator class
		$rss 	= new UniversalFeedCreator();
		// load image creator class
		$image 	= new FeedImage();
	
		// loads cache file
		if ( $showFeed && $params->cache ) {
			$rss->useCached( $params->feed, $params->file, $params->cache_time );
		}
		
		$rss->title 			= $params->title;
		$rss->description 		= $params->description;
		$rss->link 				= $params->link;
		$rss->syndicationURL 	= $params->link;
		$rss->cssStyleSheet 	= NULL;
		$rss->encoding 			= $params->encoding;

		if ( isset($params->image) ) {
			$image->url 		= $params->image;
			$image->link 		= $params->link;
			$image->title 		= $params->image_alt;
			$image->description	= $params->description;
			// loads image info into rss array
			$rss->image 		= $image;
		}
	
		if (count($parser->items) && $params->published) {
		    
 		$lastBuildDate = 0;
		$lastBuildDateString = '';
		$lastBuildDateName = '';
		foreach ($parser->items as $rssItem) { 
		       
		// load individual item creator class
		$item = new FeedItem();
		$enclosuresCounter = 0;
		
		  
		 foreach ($rssItem as $k=>$v) {
		     
		    
                 switch ($k) {
                 	case 'TITLE':
            				$item_title = htmlspecialchars( $v );
            				$item->title = html_entity_decode( $item_title );
                 		
                 		break;
                 		
                 	case 'DESCRIPTION':
            
            				// removes all formating from the intro text for the description text
            				$item_description = $v;
           		
                 		break;     		
                 		
                  	case 'LINK':
            		  		$item->link = $v;               		
                 		break;            

                  	case 'PUBDATE':

            				$item->date = $v;
            				$itemDate = strtotime($v);
            				if ($itemDate>$lastBuildDate) {
            				    $lastBuildDate = $itemDate;
            				   // $lastBuildDateString = $v;
            				}
            				
             				              		
                 		break; 
                 		
                  	case 'GUID':
            				$item->guid = $v;                 		
                 		break;                  		

                  	case 'CATEGORY':
            				$item->category = $v;                 		
                 		break;                  		                		
                 		
                  	case 'ENCLOSURE'.$parser->separationSymbol.'URL':
            				$item->enclosures[$enclosuresCounter]['url'] = $v;                 		
                 		break;
                 		                   		  
                  	case 'ENCLOSURE'.$parser->separationSymbol.'LENGTH':
            				$item->enclosures[$enclosuresCounter]['length'] = $v;                 		
                 		break;                  		
                 		  
                  	case 'ENCLOSURE'.$parser->separationSymbol.'TYPE':
            				$item->enclosures[$enclosuresCounter]['type'] = $v;                 		
                 		break;                  		
                 		
                   	case 'ITUNES:AUTHOR':
            				$item->itunes_author = $v;                 		
                 		break; 
                   	case 'ITUNES:SUBTITLE':
            				$item->itunes_subtitle = $v;                 		
                 		break;                  		                		
                   	case 'ITUNES:SUMMARY':
            				$item->itunes_summary = $v;                 		
                 		break;                   		
                   	case 'ITUNES:DURATION':
            				$item->itunes_duration = $v;                 		
                 		break;                  		
                   	case 'ITUNES:KEYWORDS':
            				$item->itunes_keywords = $v;                 		
                 		break; 
                 		                 		
                 	default:
               	
                 		break;
                 }
		    }
		    
		    
		    if (!empty($item->enclosures) && $item->enclosures[$enclosuresCounter]['length'] != '') {
		          $enclosuresCounter++;    
		    }
		     

				// item info
				$item->description 	= $item_description;
				$item->source 		= $params->link;
				
				// loads item info into rss array
				$rss->addItem( $item ); 
		}	    
		    
	if ($lastBuildDate>0) {
	$lastBuildDate 		= date("Y-m-d H:i:s", $lastBuildDate);
	}

	$query = "UPDATE #__fdr_feeds SET modified = '".$lastBuildDate."' WHERE Id = '$feed->Id' AND internal = '0'";
	$db->setQuery($query);
	$db->query();		    
		    

		}
		//save feed file

		$rss->saveFeed( $params->feed, $params->file, $showFeed );

    
}


function compile ($feed) {
    
        $db = $GLOBALS['database'];
        $mainframe = $GLOBALS['mainframe'];
        $mosConfig_live_site = $GLOBALS['mosConfig_live_site'];

		$mosConfig_offset = $GLOBALS['mosConfig_offset'];
		$mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path'];
		
		$showFeed = true;
		
		$params = getParameters($feed);

		// set filename for live bookmarks feed
		if ( !$showFeed & $params->live_bookmark ) {
			// standard bookmark filename
			$params->file = $mosConfig_absolute_path .'/cache/'. $params->live_bookmark . "_" . $feed->Id;
		} else {
		// set filename for rss feeds
			$params->file = strtolower( str_replace( '.', '', $params->feed ) );
			$params->file = $mosConfig_absolute_path .'/cache/'. $params->file. "_" .$feed->Id .'.xml';
		}
		
	
		// load feed creator class
		$rss 	= new UniversalFeedCreator();
		// load image creator class
		$image 	= new FeedImage();
	
		// loads cache file
		if ( $showFeed && $params->cache ) {
			$rss->useCached( $params->feed, $params->file, $params->cache_time );
		}
		
		$rss->title 			= $params->title;
		$rss->description 		= $params->description;
		$rss->link 				= $params->link;
		$rss->syndicationURL 	= $params->link;
		$rss->cssStyleSheet 	= NULL;
		$rss->encoding 			= $params->encoding;

		if ( isset($params->image) ) {
			$image->url 		= $params->image;
			$image->link 		= $params->link;
			$image->title 		= $params->image_alt;
			$image->description	= $params->description;
			// loads image info into rss array
			$rss->image 		= $image;
		}
		
		
		$rows = getDataCompilation($params, $feed);
		
    
	getItemsCompiled ($rows, $params, $rss);	
		


		
		//save feed file

		$rss->saveFeed( $params->feed, $params->file, $showFeed );

 
}




	function getParameters ($feed) {
	    
        $mosConfig_live_site = $GLOBALS['mosConfig_live_site'];
		$mosConfig_offset = $GLOBALS['mosConfig_offset'];	
		$db = $GLOBALS['database'];
		
		$params = new mosParameters('');
	
		$params->id =$feed->Id;
		$params->published = $feed->published;
		if (method_exists($db,"getNullDate")) {		
			$params->nullDate 	= $db->getNullDate();
		} else {
			$params->nullDate = '0000-00-00 00:00:00';
		}		
		$params->now 		= date( 'Y-m-d H:i:s', time() + $mosConfig_offset * 60 * 60 );
		$iso 		= split( '=', _ISO );
		

			$details = 'Joomla! site syndication';

			if ($feed->internal && $feed->section_based && $feed->id_section != '' && $feed->id_section != '0') {
			    	$query = "SELECT s.title"
                    	. "\n FROM #__sections AS s"
                    	. "\n WHERE id = '$feed->id_section'";
                    $db->setQuery( $query );
                    $sectionName = $db->loadResult();
			    
			        $details .= ' '.$sectionName.' ';
			        
			        if ($feed->id_category != '' && $feed->id_category != '0') {
			            $details .= '; ';
    			        $query = "SELECT c.title"
                        	. "\n FROM #__categories AS c"
                        	. "\n WHERE id = '$feed->id_category'";
                        $db->setQuery( $query );
                        $categoryName = $db->loadResult();
    			    
    			        $details .= ' '.$categoryName.' ';
			        }
			} 			
			
			if ($feed->internal && $feed->keywords_based && $feed->keywords != '') {  
			        if ($feed->id_section != '' && $feed->id_section != '0') {
			             $details .= '; ';    
			        }			
    				$details .= 'Only content items related to the following keywords are shown: '.$feed->keywords.' ';
			}		
		

		
		// parameter intilization
		$params->date    		= date( 'r' );
		$params->year    		= date( 'Y' );
		$params->encoding    	= $iso[1];
		$params->link    		= htmlspecialchars( $mosConfig_live_site );
		$params->cache    		= $feed->cache;
		$params->cache_time    	= $feed->cache_refresh_time;
		$params->count   		= $params->def( 'count', 5 );
		$params->orderby    	= $params->def( 'orderby', '' );
		$params->title    		= $feed->name;
		$params->description   	= $details;
		if (!$feed->published) {
		      $params->description   	= 'We\'re sorry, this feed is currently not available';    
		}
		$params->image_file   	= $params->def( 'image_file', 'joomla_rss.png' );
		if ( $params->image_file  == -1 ) {
			$params->image	= NULL;
		} else{
			if (isset($info)) {
		      $params->image	= $mosConfig_live_site .'/images/M_images/'. $info[ 'image_file' ];
			}
		}
		$params->image_alt    	= $params->def( 'image_alt', 'Powered by Joomla!' );
		$params->limit_text    	= $params->def( 'limit_text', 1 );
		$params->text_length    	= $params->def( 'text_length', 20 );
		// get feed type from url
		$params->feed    		= $feed->format;//mosGetParam( $_GET, 'feed', 'RSS2.0' );
		// live bookmarks
		$params->live_bookmark   	= $params->def( 'live_bookmark', '' );

		return $params;
	}	

	function getData ($params, $feed) {
		$db = $GLOBALS['database'];
		
		$nullDate = $params->nullDate;
		$now = $params->now;
		
		$and 		= '';
		$join = '';	
		

		  if ($feed->keywords_based && $feed->keywords != '') {
    		  $join .= "\n LEFT JOIN #__fdr_ku AS k ON k.id_content = a.id";
    		  $join .= "\n LEFT JOIN #__fdr_kurss AS kr ON kr.keyword = k.keyword"; 
    		  $and .= "\n AND kr.id_rss = '".$params->id."'";  
		  }
		  
		  if ($feed->section_based && $feed->id_section != '' && $feed->id_section != '0') {
		      $and .= "\n AND a.sectionid = '".$feed->id_section."'";
		  }
		  
		  if ($feed->id_category != '' && $feed->id_category != '0') {
    		$and  .= "\n AND a.catid = '".$feed->id_category."'";
		  }
    		$query = "SELECT a.*, u.name AS author, u.usertype, UNIX_TIMESTAMP( a.created ) AS created_ts"
    		. "\n FROM #__content AS a"   		  
    		. $join
    		. "\n LEFT JOIN #__users AS u ON u.id = a.created_by"
    		. "\n WHERE a.state = 1"
    		. $and;
    	  if (!$feed->ignore_accesslevel) $query .= "\n AND a.access = 0";
    		$query .= "\n AND ( a.publish_up = '$nullDate' OR a.publish_up <= '$now' )"
    		. "\n AND ( a.publish_down = '$nullDate' OR a.publish_down >= '$now' )"
    		. "\n ORDER BY $feed->orderby $feed->ordering_direction"
    		. ( $feed->count ? "\n LIMIT ". $feed->count : '' )
    		;

		
		// query of content items

		
		$db->setQuery( $query );

		$rows = $db->loadObjectList();
		
		return $rows;

	}
	
	function getDataCompilation ($params, $feed) {
		$db = $GLOBALS['database'];
		
		
		$frontpage = 0; //TODO: needs to be modified
		
		// Determine ordering for sql
		switch ( strtolower( $params->orderby ) ) {
			case 'date':
				$orderby = 'i.parsing_time';
				break;
	
			case 'rdate':
				$orderby = 'i.parsing_time DESC';
				break;
	
			case 'alpha':
				$orderby = 'i.title';
				break;
	
			case 'ralpha':
				$orderby = 'i.title DESC';
				break;
	
			default:
                $orderby = 'i.parsing_time';
				break;
		}
	
		$nullDate = $params->nullDate;
		$now = $params->now;
		
		$and 		= '';
		$join = '';	
		


    		  $join .= "\n LEFT JOIN #__fdr_parsed_items_ku AS k ON k.id_parsed_item = i.Id";
    		  $join .= "\n LEFT JOIN #__fdr_kurss AS kr ON kr.keyword = k.keyword"; 
    		 // $join .= "\n LEFT JOIN #__fdr_feeds AS f ON f.Id = kr.id_rss"; 
    		  $and .= "\n AND kr.id_rss = '".$params->id."'";
    		  //$and .= "\n AND f.published = '1'";  

    		$query = "SELECT i.*"
    		. "\n FROM #__fdr_parsed_items AS i"   		  
    		. $join
    		. "\n WHERE i.format = '$feed->format'"
    		. $and
       		. "\n ORDER BY $orderby"
    		//. ( $params->count ? "\n LIMIT ". $params->count : '' )
    		;

		
		// query of content items

		
		$db->setQuery( $query );

		$rows = $db->loadObjectList();
		
		return $rows;

	}	


?>