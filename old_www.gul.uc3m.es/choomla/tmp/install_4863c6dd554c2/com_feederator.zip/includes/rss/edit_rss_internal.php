<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

		mosCommonHTML::loadOverlib();
		mosCommonHTML::loadCalendar();

		$_FDR_LANG = $GLOBALS['_FDR_LANG'];
		$option = $GLOBALS['option'];
		$task = $GLOBALS['task'];
		$id = $GLOBALS['id'];

		$lists = array();

		$lists['published'] = mosHTML::yesnoSelectList('published', '', $row->published);
		$lists['cache'] = mosHTML::yesnoSelectList('cache', '', $row->cache);

	$javascript = "onchange=\"changeDynaList( 'id_category', sectioncategories, document.adminForm.id_section.options[document.adminForm.id_section.selectedIndex].value, 0, 0);\"";

	$query = "SELECT s.id, s.title"
	. "\n FROM #__sections AS s"
	. "\n ORDER BY s.ordering";
	$database->setQuery( $query );
	if ( $row->id_section == 0 || $row->id_section == '' ) {
		$sections[] = mosHTML::makeOption( '-1', 'Select Section', 'id', 'title' );
		$sections = array_merge( $sections, $database->loadObjectList() );
		$lists['sectionid'] = mosHTML::selectList( $sections, 'id_section', 'class="inputbox" size="1" '. $javascript, 'id', 'title' );
	} else {
		$sections = $database->loadObjectList();
		$lists['sectionid'] = mosHTML::selectList( $sections, 'id_section', 'class="inputbox" size="1" '. $javascript, 'id', 'title', intval( $row->id_section ) );
	}
	
	$javascript = '';
	for ($i = 1; $i < 11; $i++) {
    	$itemsCount[] = mosHTML::makeOption( $i*5, $i*5, 'id', 'title' );
	}	
	$lists['itemsCount'] = mosHTML::selectList( $itemsCount, 'count', 'class="inputbox" size="1" '. $javascript, 'id', 'title', intval( $row->count ) );
	
	$orderby[] = mosHTML::makeOption( 'date', 'Creation Date', 'id', 'title' );
	$orderby[] = mosHTML::makeOption( 'title', 'Title', 'id', 'title' );
	$orderby[] = mosHTML::makeOption( 'hits', 'Hits', 'id', 'title' );
	$orderby[] = mosHTML::makeOption( 'front', 'Frontpage Ordering', 'id', 'title' );
	$lists['orderby'] = mosHTML::selectList( $orderby, 'orderby', 'class="inputbox" size="1" '. $javascript, 'id', 'title', Recly_RSS::convertOrderingFromDB($row->orderby) );

	$ordering_direction[] = mosHTML::makeOption( 'desc', 'Descent', 'id', 'title' );
	$ordering_direction[] = mosHTML::makeOption( 'asc', 'Ascent', 'id', 'title' );
	$lists['ordering_direction'] = mosHTML::selectList( $ordering_direction, 'ordering_direction', 'class="inputbox" size="1" '. $javascript, 'id', 'title', ($row->ordering_direction == 'ASC' ? 'asc' : 'desc'));

	$javascript = "onchange=\"toggleIntro(this.options[this.selectedIndex].value);\"";
	$show_full[] = mosHTML::makeOption( '0', 'intro only', 'id', 'title' );
	$show_full[] = mosHTML::makeOption( '1', 'full story', 'id', 'title' );
	$lists['show_full'] = mosHTML::selectList( $show_full, 'show_full', 'class="inputbox" size="1" '. $javascript, 'id', 'title', $row->show_full );

	$javascript = "";
	$limit_text[] = mosHTML::makeOption( '0', 'Don\'t limit number of words', 'id', 'title' );
	$limit_text[] = mosHTML::makeOption( '10', 'Allow 10 words only', 'id', 'title' );
	$limit_text[] = mosHTML::makeOption( '25', 'Allow 25 words only', 'id', 'title' );
	$limit_text[] = mosHTML::makeOption( '50', 'Allow 50 words only', 'id', 'title' );
	$lists['limit_text'] = mosHTML::selectList( $limit_text, 'limit_text', 'class="inputbox" size="1" '. $javascript, 'id', 'title', $row->limit_text );
		
	
	$contentSection = '';
	foreach($sections as $section) {
		$section_list[] = $section->id;
		// get the type name - which is a special category
		if ($row->id_section == $row->id_section ) {
				$contentSection = $section->title;
			}

	}

	$sectioncategories 			= array();
	$sectioncategories[-1] 		= array();
	$sectioncategories[-1][] 	= mosHTML::makeOption( '-1', 'Select Category', 'id', 'name' );
	mosArrayToInts( $section_list );
	$section_list 				= 'section=' . implode( ' OR section=', $section_list );

	$query = "SELECT id, name, section"
	. "\n FROM #__categories"
	. "\n WHERE ( $section_list )"
	. "\n ORDER BY ordering"
	;
	$database->setQuery( $query );
	$cat_list = $database->loadObjectList();
	foreach($sections as $section) {
		$sectioncategories[$section->id] = array();

		$rows2 = array();
		$rows3 = array();


		foreach($cat_list as $cat) {
			if ($cat->section == $section->id) {
				$rows2[] = $cat;
			}
		}

		if (count($rows2)>1) {
    		$allCat->id = 0;
    		$allCat->name = "All Categories";
    		$rows3[] = $allCat;
		}


		$rows2 		= array_merge( $rows3, $rows2 );

		foreach($rows2 as $row2) {
			$sectioncategories[$section->id][] = mosHTML::makeOption( $row2->id, $row2->name, 'id', 'name' );
		}
	}

 	// get list of categories
  	if ( !$row->id_category && !$row->id_section ) {
 		$categories[] 		= mosHTML::makeOption( '-1', 'Select Category', 'id', 'name' );
 		$lists['catid'] 	= mosHTML::selectList( $categories, 'id_category', 'class="inputbox" size="1"', 'id', 'name' );
  	} else {
		$categoriesA = array();
		if ( $row->id_section == 0 ) {
			//$where = "\n WHERE section NOT LIKE '%com_%'";
			foreach($cat_list as $cat) {
				$categoriesA[] = $cat;
			}
		} else {
			//$where = "\n WHERE section = '$sectionid'";
			foreach($cat_list as $cat) {
				if ($cat->section == $row->id_section) {
					$categoriesA[] = $cat;
				}
			}
		}
		//$categories[] 		= mosHTML::makeOption( '-1', 'Select Category', 'id', 'name' );
		$categories[] 		= mosHTML::makeOption( '0', 'All Categories', 'id', 'name' );
		$categories 		= array_merge( $categories, $categoriesA );
 		$lists['catid'] 	= mosHTML::selectList( $categories, 'id_category', 'class="inputbox" size="1"', 'id', 'name', intval( $row->id_category ) );
  	}


 		$feedTypes[]        = mosHTML::makeOption( 'RSS2.0', 'RSS2.0', 'id', 'name' );
 		$feedTypes[]        = mosHTML::makeOption( 'iTunesDTD2.0', 'iTunes DTD2.0', 'id', 'name' );
 		$lists['feeds'] 	= mosHTML::selectList( $feedTypes, 'format', 'class="inputbox" size="1"', 'id', 'name' ,$row->format );


		?>
		<script language="javascript" type="text/javascript">
		<!--

		var sectioncategories = new Array;
		<?php
		$i = 0;
		foreach ($sectioncategories as $k=>$items) {
			foreach ($items as $v) {
				echo "sectioncategories[".$i++."] = new Array( '$k','".addslashes( $v->id )."','".addslashes( $v->name )."' );\t";
			}
		}
		?>

			function submitbutton(pressbutton) {
				var form = document.adminForm;
				var sections_disabled = document.forms['adminForm'].id_section.disabled;
				var internal = document.forms['adminForm'].internal.value;


				if (pressbutton != '') {
					if (pressbutton == 'cancel') {
						submitform( pressbutton );
					} else {

						// do field validation
						if (form.name.value == ""){
							alert( "Item must have a name" );
						} else if (internal == '1' && !sections_disabled && form.id_section.value == "-1"){
            				alert( "You must select a Section." );
            			} else if (internal == '1' && !sections_disabled && form.id_category.value == "-1"){
				            alert( "You must select a Category." );
 			            } else if (internal == '1' && !sections_disabled && form.id_category.value == ""){
 				            alert( "You must select a Category." );
			            } else {
						    submitform( pressbutton );
						}
					}
				}
			}

	function pullKeywords() {
		this.document.filename.dataLoaded.value = '1';
		xajax_instDefault(xajax.getFormValues('filename'));
	}
	
	function toggleIntro (show_full) {
	    var limit_text = document.getElementById("limit_text");
	    if (show_full == 0) {
	       limit_text.style["display"] = "";  	    
	    } else {
	       limit_text.style["display"] = "none";
	    }
	    
	return;
	}


		//-->
		</script>
<?php
    echo $toolbar->open();
    echo $toolbar->button('save', 'Save', 'save', '0');
    echo $toolbar->button('apply', 'Apply', 'apply', '0');
    echo $toolbar->button('cancel', 'Cancel', 'cancel', '0');
    echo $toolbar->close('static', $_FDR_LANG->EDIT_INTERNAL_RSS_FEED.': "'.$row->name.'"');

	?>

		<form action="index2.php" method="post" name="adminForm">


		<table cellspacing="2" cellpadding="0" width="100%">
		<tr><td width="100%" valign="top">

			<table class="adminform"><tr><th colspan="3" >
			<b><?php echo $_FDR_LANG->SETTINGS;?></b>
			</th></tr>

			<tr><td valign="top" align="right" width="20%">
			<b><?php echo $_FDR_LANG->NAME;?></b>&nbsp;(<a href="<?php echo $mosConfig_live_site.'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row->Id;?>">URL</a>)
			</td><td>
			<input type="text" name="name" size="50" maxlength="255" value="<?php echo $row->name; ?>" class="text_area" />
			</td><td>
			Name of RSS feed
			</td>
			</tr>

			<tr><td valign="top" align="right">
			<b><?php echo $_FDR_LANG->PUBLISHED;?></b>
			</td><td colspan="2">
			<?php echo $lists['published'];?>
			</td></tr>

			<tr><td valign="top" align="right" width="40%">
			<input type="checkbox" name="section_based" value="1" <?php if ($row->section_based) echo "checked";?> onClick="javascript:enableSections();"><b><?php echo 'Set specific section for the content to be pulled from';?></b>
			</td><td>
			<?php echo $lists['sectionid']; ?>

			</td><td valign="top">
			</td>
			</tr>

			<tr><td valign="top" align="right" width="40%">
			&nbsp;
			</td><td>
			<?php echo $lists['catid']; ?>
			</td><td valign="top">
			</td>
			</tr>

			<tr><td valign="top" align="right">
			<b><?php echo 'Number of RSS items to show';?></b>
			</td>
			<td valign="top">
			<?php echo $lists['itemsCount']; ?>
			</td>
			<td valign="top">
			Select number of items to display in this feed
			</td>
			</tr>	
			
			<tr><td valign="top" align="right">
			<b><?php echo 'Order RSS items by';?></b>
			</td>
			<td valign="top">
			<?php echo $lists['orderby']; ?>, direction:<?php echo $lists['ordering_direction']; ?>
			</td>
			<td valign="top">
			Please select preferable ordering
			</td>
			</tr>	

			<tr><td valign="top" align="right">
			<b><?php echo 'Display '.$lists['show_full'].' in the RSS items';?></b>
			</td>
			<td valign="top">
			<div id="limit_text"><?php echo $lists['limit_text']; ?></div>
			</td>
			<td valign="top">
			Choose if you want to display full articles or just limited number of words
			</td>
			</tr>						

			
			<tr><td valign="top" align="right">

			<input type="checkbox" name="ignore_accesslevel" value="1" <?php if ($row->ignore_accesslevel) echo "checked";?> ><b><?php echo 'Ignore Access Level';?></b>


			</td><td valign="top" colspan="2">
			When checked, RSS Feed generator will ignore access level settings (public/registered) of articles, and will pull them all to the feed, regardless of what was set for each individual article.
			</td>
			</tr>

			<tr><td valign="top" align="right" width="40%">
			<b>Assign Itemid</b>
			</td><td>
			<input type="text" name="itemid" size="10" value="<?php echo $row->itemid; ?>" class="text_area" />
			</td><td valign="top">
			In case if some article doesn't have its own unique Itemid, will be used the one you assigned here.
			</td>
			</tr>
			<tr><td valign="top" align="right" width="40%">
			<input type="checkbox" name="keywords_based" value="1" <?php if ($row->keywords_based) echo "checked";?> onClick="javascript:enableKeywords();"><b><?php echo 'Filter content by these keywords';?></b><br>
			<i>Please note, that to enable this feature, you need to make the changes to one of the Joomla core files as explained in readme.txt</i>
			</td><td>
			<textarea name="keywords" cols="35" rows="10"><?php echo $row->keywords;?></textarea>
			</td><td valign="top">
			Enter keywords you want to create RSS feed for. Just content items with given keywords in metatags will be pulled for this feed.<br>
			Please note, that Feederator treats "football team" as a whole keyword rather than two keywords "football" and "team".
			</td>
			</tr>

			<tr><td valign="top" align="right">
			<b><?php echo $_FDR_LANG->CACHE_ENABLED;?></b>
			</td><td>
			<?php echo $lists['cache'];?>
			</td><td valign="top">
			If you enable cache, RSS will be generated once and will be kept as a file during Cache Timeout period
			</td>
			</tr>

			<tr><td valign="top" align="right" width="40%">
			<b><?php echo $_FDR_LANG->CACHE_TIMEOUT;?></b>
			</td><td>
			<input type="text" name="cache_refresh_time" size="10" value="<?php echo $row->cache_refresh_time; ?>" class="text_area" />
			</td><td valign="top">
			Cache Timeout period (3600 seconds is equal to 1 hour)
			</td>
			</tr>

			<tr><td valign="top" align="right" width="40%">
			<b><?php echo 'PIN';?></b>
			</td><td>
			<input type="text" name="pin" size="8" value="<?php echo $row->pin; ?>" class="text_area" />
			</td><td valign="top">
			You can assign identification number to this feed
			</td>
			</tr>

			</table>


		</td></tr>
		</table>


		<input type="hidden" name="id" value="<?php echo $row->Id;?>" />
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="keywords_based_checked" value="<?php echo $row->keywords_based;?>" />
		<input type="hidden" name="section_based_checked" value="<?php echo $row->section_based;?>" />
		<input type="hidden" name="internal" value="1" />
		<input type="hidden" name="hidemainmenu" value="0" />

		</form><br />

       <script language="JavaScript">

        function enableKeywords() {
            var keywords_based = document.forms['adminForm'].keywords_based_checked.value;
            var internal = document.forms['adminForm'].internal.value;

            if (internal == '1' && (keywords_based == '0' || keywords_based == '')) {

              document.forms['adminForm'].keywords.disabled = true;
              document.forms['adminForm'].keywords_based_checked.value = 1;

            } else {

              document.forms['adminForm'].keywords.disabled = false;
              document.forms['adminForm'].keywords_based_checked.value = 0;


            }

        }

         function enableSections() {
            var section_based = document.forms['adminForm'].section_based_checked.value;
            var internal = document.forms['adminForm'].internal.value;

            if (internal == '1') {
                if (section_based == '0' || section_based == '') {

                  document.forms['adminForm'].id_category.disabled = true;
                  document.forms['adminForm'].id_section.disabled = true;
                  document.forms['adminForm'].section_based_checked.value = 1;

                } else {

                  document.forms['adminForm'].id_category.disabled = false;
                  document.forms['adminForm'].id_section.disabled = false;
                  document.forms['adminForm'].section_based_checked.value = 0;


                }
            }

        }

        enableKeywords();
        enableSections();
        
        var limit_text = document.getElementById("limit_text");
        
      <?php
     
        if (!$row->show_full) 
        {
            echo 'limit_text.style["display"] = "";';
        } else 
        {
            echo 'limit_text.style["display"] = "none";';
        }
      ?>  

		</script>


		<?php


?>