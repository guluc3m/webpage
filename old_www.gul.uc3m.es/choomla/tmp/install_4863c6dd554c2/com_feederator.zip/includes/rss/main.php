<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

// load feed creator class
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_Toolbar.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_Paginator.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_HTML.php' );


	if ($my->id <= 0) {
		mosNotAuth();
		return;
	}


switch ( $task ) {

    case 'cancel':
	case 'list_feeds':	
         listFeeds();
      break;   
      

    case 'remove_feeds':
    
    $feed = new Recly_RSS('Id','#__fdr_');
    
         foreach ($id as $i) {
         	 $feed->delete($i); 
         }
         mosRedirect( $GLOBALS['mosConfig_live_site'].'/index.php?option=com_feederator&task=list_feeds&limit='.$limit.'&limitstart='.$limitstart.'&archived='.$archived.'&orderBy='.$orderBy.'&ordering='.$ordering, "Selected feeds were successfully deleted" );
     break;           
           
      
}

function listFeeds() {
	
    
    $limit = mosGetParam($_REQUEST, 'limit', 30);	
    $limitstart = mosGetParam($_REQUEST, 'limitstart', 0);	
    $search = mosGetParam($_REQUEST, 'search', '');
    $orderBy = mosGetParam($_REQUEST, 'orderBy', 'c.Id'); 
    $ordering = mosGetParam($_REQUEST, 'ordering', 'DESC'); 
    $archived = mosGetParam($_REQUEST, 'archived', '0'); 
    $filterType = mosGetParam($_REQUEST, 'filterType', '0'); 
    $filterBy = mosGetParam($_REQUEST, 'filterBy', '');
    
    $my = $GLOBALS['my'];
        
            		$where = "WHERE created_by = '".$my->id."' ";
            		if ($search!='') {
            			$where .= "AND name LIKE '%$search%' ";
            		}
         
    $query = "SELECT COUNT(*) FROM #__fdr_feeds
    $where";
  
    
    $GLOBALS['database']->setQuery($query);
    $total = $GLOBALS['database']->loadResult();    
    
$pageNav = new Recly_Paginator( $total, $limitstart, $limit );    
    

            		$query = "SELECT * "
            		. "\n  FROM  #__fdr_feeds "
            		. "\n $where "
            		. "\n ORDER BY name "
            		;
    
 
    
    $GLOBALS['database']->setQuery($query, $pageNav->limitstart, $pageNav->limit );
    $rows = $GLOBALS['database']->loadObjectList();
    
  

   $savant = new Savant2($GLOBALS['savantConf']);
   
   
$savantToolbarConf = array (
		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/components/com_feederator/templates/toolbar/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'template_URL' => $GLOBALS['mosConfig_live_site'] . "/components/com_feederator/templates/toolbar/"
);   


   $toolbar = new Recly_Toolbar('adminForm', $savantToolbarConf);

    $caption = "RSS Feeds";
  
    $toolbar->enableStyles();
    $toolbar->enableStyles();
    echo $toolbar->open();    
    echo $toolbar->button('new', 'New', 'createFeed');   
    echo $toolbar->button('delete', 'Delete', 'remove_feeds', '1');    
    echo $toolbar->close('categories', $caption);
    
    $savant->assign('limit', $limit);
    $savant->assign('limitstart', $limitstart);
    $savant->assign('search', $search);
    $savant->assign('rows', $rows);
    $savant->assign('pageNav', $pageNav);
    $savant->display('rss/rss.tpl.php');

}

?>