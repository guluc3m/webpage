<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

    $caption = "Add RSS Feed: step 1 of 2";

    //$toolbar->enableStyles();
    echo $toolbar->open();
    echo $toolbar->button('apply', 'Next step', 'new_feed_step2', '0');
    echo $toolbar->button('cancel', 'Cancel', 'cancel', '0');
    echo $toolbar->close('static', $caption);

?>

	<form action="index2.php" method="post" name="adminForm">

		<table cellspacing="2" cellpadding="0" width="100%">
		<tr><td width="100%" valign="top">

			<table class="adminform"><tr><th colspan="3" >
			<b><?php echo 'Please select type of the feed you\'re adding';?></b>
			</th></tr>

			<tr><td valign="top" align="right" width="5">
			<input type="radio" name="feedType" value="1" checked>
			</td><td>
			<b><?php echo 'Internal';?></b>
			</td><td>
			Internal RSS Feed is based on the information from this website (local database)
			</td>
			</tr>


				<?php
				$isDisabled = '';
				$onlyPremium = '';
				if ($globalVariables->get('mode') == 'demo') {
				    $isDisabled = 'disabled';
				    $onlyPremium = '(<font color="#FF0000">Only in the Premium version</font>)';
				} ?>
			<tr><td valign="top" align="right" >
			<input type="radio" name="feedType" value="2" <?php echo $isDisabled;?>>
			</td><td>
			<b><?php echo 'External';?></b> <?php echo $onlyPremium;?>

			</td><td>
			Select this type if you want to publish or "rebrand" external RSS Feed. You can also "rebrand" already existing "local" feed.
			</td>
			</tr>


				<?php
				$isDisabled = '';
				$onlyPremium = '';
				if ($globalVariables->get('mode') == 'demo') {
				    $isDisabled = 'disabled';
				    $onlyPremium = '(<font color="#FF0000">Only in the Premium version</font>)';
				} ?>
			<tr><td valign="top" align="right">
			<input type="radio" name="feedType" value="3" <?php echo $isDisabled;?>>
			</td><td>
			<b><?php echo 'Compiled';?></b> <?php echo $onlyPremium;?>
			</td><td>
			Compiled RSS feeds created out of individual items that come from various sources.
			</td>
			</tr>

			</table>


		</td></tr>
		</table>


		<input type="hidden" name="id" value="0" />
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="task" value="save" />
		<input type="hidden" name="hidemainmenu" value="0" />
		<input type="hidden" name="keywords_based_checked" value="" />
		<input type="hidden" name="section_based_checked" value="" />
		<input type="hidden" name="is_internal_feed" value="" />
		<input type="hidden" name="hidemainmenu" value="0" />

		</form><br />