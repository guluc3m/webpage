<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_Paginator.php' );
require_once($GLOBALS['mosConfig_absolute_path'] . "/components/Recly/Recly_Keywords/Recly_Keywords.php");
require_once($mosConfig_absolute_path . '/components/Recly/common/GlobalVariables.php');

		$_FDR_LANG = $GLOBALS['_FDR_LANG'];

		$search = mosGetParam($_REQUEST, 'search', '');
		$order = mosGetParam($_REQUEST, 'order', '');
		$orderBy = mosGetParam($_REQUEST, 'orderBy', '');
		$ordering = mosGetParam($_REQUEST, 'ordering', '');

		switch ($task) {
		    case 'apply':
			case 'save':

			    if (is_array($id)) $id = $id[0];

        		$row = new Recly_RSS('Id','#__fdr_');
        		$krow = new Recly_Keywords('id_rss','keyword', '#__fdr_', 'kurss');

        		if (isset($my) && $my->id != '0') {
        		  $row->modified_by = $my->id;
        		}

         		$row->id_category = mosGetParam($_REQUEST, 'id_category', '0');
        		$row->id_section = mosGetParam($_REQUEST, 'id_section', '0');
        		$row->name = mosGetParam($_REQUEST, 'name', 'not set');
        		$row->published = mosGetParam($_REQUEST, 'published', '0');
        		$row->section_based = mosGetParam($_REQUEST, 'section_based', '0');
        		$row->internal = mosGetParam($_REQUEST, 'internal', '1');
        		$row->keywords_based = mosGetParam($_REQUEST, 'keywords_based', '0');
        		$row->pin = mosGetParam($_REQUEST, 'pin', '0');
        		$row->cache = mosGetParam($_REQUEST, 'cache', '0');
        		$row->ignore_accesslevel = mosGetParam($_REQUEST, 'ignore_accesslevel', '0');
        		$row->cache_refresh_time = mosGetParam($_REQUEST, 'cache_refresh_time', '3600');
        		$row->itemid = intval(mosGetParam($_REQUEST, 'itemid', '0'));
        		if (($row->keywords_based && $row->internal == '1')
        		|| ($row->internal == '0')
        		|| ($row->internal == '2')) {
        		  $row->keywords = Recly_Preparator::prepareForSQL(mosGetParam($_REQUEST, 'keywords', '' ));
        		}
        		$row->url = Recly_Preparator::prepareForSQL(mosGetParam($_REQUEST, 'url', ''));
        		$row->tag_to_pull_keywords_from = mosGetParam($_REQUEST, 'tag_to_pull_keywords_from', '');
        		$row->format = mosGetParam($_REQUEST, 'format', 'RSS2.0');

        		$row->modified = date("Y-m-d H:i:s", time());

        		$row->count = (int)mosGetParam($_REQUEST, 'count', 5); 
        		$row->orderby = Recly_RSS::convertOrderingToDB(mosGetParam($_REQUEST, 'orderby', 'date'));
        		$row->ordering_direction = (mosGetParam($_REQUEST, 'ordering_direction', 'desc') == 'asc') ? 'ASC' : 'DESC';       		
        		$row->show_full = (int)mosGetParam($_REQUEST, 'show_full', 0); 
        		$row->limit_text = (int)mosGetParam($_REQUEST, 'limit_text', 0);       		        		

        		if ($id != '' && $id != '0') {
        		    $row->Id = $id;
                    //$row->bindToTable ();
        		} else {
        		    $row->created = date("Y-m-d H:i:s", time());
            		if (isset($my) && $my->id != '0') {
            		  $row->created_by = $my->id;
            		}
             		$row->_tbl_key = '';
        		}


        		if (!$row->store()) {
        			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
        			echo $row->getError()."<hr>";
        			exit();
        		}


        		$krow->saveKeywords($row->Id, $row->keywords);

        		$msg = $row->name . $_FDR_LANG->SCSA;

        		$row->bindFromTable();

        		if ('apply' == $task) {
        			mosRedirect( "index2.php?option=com_feederator&task=edit&id=$row->Id", $msg );
        		} elseif ('save' == $task) {
        			mosRedirect( "index2.php?option=com_feederator&task=list", $msg );
        		}

				break;

			case 'publish':
			     publish( 1 );
			break;

			case 'unpublish':
			     publish( 0 );
			break;

			case 'delete':
			     delete();
			break;

			default:
					$limit = $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit );
            		$limitstart = $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 );
            		$filter = "";
            		if ($search) {
            			$filter .= "WHERE name like '%$search%'";
            		}

            		// get the total number of records
            		$database->setQuery( "SELECT count(*) FROM #__fdr_feeds $filter");

            		$total = $database->loadResult();

            		$pageNav = new Recly_Paginator( $total, $limitstart, $limit );

     $order = '';
    //if ($orderBy != '') {
        switch ($orderBy) {
        	case 'feed_name':
        		  $orderByField = 'name';
        		break;
        	case 'feed_mofified_date':
        		  $orderByField = 'modified';
        		break;
        	case 'feed_id':
        	default:
        	      $orderByField = 'Id';
        		break;
        }
   // }



            		$query = "SELECT * "
            		. "\n  FROM  #__fdr_feeds "
            		. "\n $filter "
            		. "\n ORDER BY $orderByField $ordering "
            		;
            		$database->setQuery( $query, $pageNav->limitstart, $pageNav->limit );
            		//echo $database->getQuery()."<hr>";
            		$rows = $database->loadObjectList();

            		if ($database->getErrorNum()) {
            			echo $database->stderr();
            			return false;
            		}

			        show( $option,  $task, $rows, $pageNav, $search, $toolbar );
				break;
		}


	function publish( $state=0 )	{
		global $database, $my;

		$_FDR_LANG = $GLOBALS['_FDR_LANG'];
		$option = $GLOBALS['option'];
		$task = $GLOBALS['task'];

		$id = $GLOBALS['id'];
		$search = mosGetParam($_REQUEST, 'search', '');

		if (count( $id ) < 1) {
			$action = $state == 1 ? $_FDR_LANG->PUBLISHED : $_FDR_LANG->UNPUBLISHED;
			echo "<script> alert('".$_FDR_LANG->SELITEM." to be $action'); window.history.go(-1);</script>\n";
			exit;
		}

		$total = count ( $id );
		$ids = (count( $id ) == 1) ? $id[0] : implode( ',', $id );

		$query = "UPDATE #__fdr_feeds"
		. "\n SET published = $state"
		. "\n WHERE Id IN ( $ids )"
		;
		$database->setQuery( $query );
		//echo $database->getQuery()."<hr>";

		if (!$database->query()) {
			echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
			exit();
		}


		if ( $state == "1" ) {
			$msg = $total . $_FDR_LANG->ITEMSP;
		} else if ( $state == "0" ) {
			$msg = $total . $_FDR_LANG->ITEMSUP;
		}

		mosRedirect( 'index2.php?option='. $option . '&amp;task=list&amp;search='. $search . '&mosmsg='. $msg );
	}

	function delete() {
		global $database;

		$option = $GLOBALS['option'];
		$task = $GLOBALS['task'];
		$id = $GLOBALS['id'];

		$row = new Recly_RSS( 'Id','#__fdr_' );
		$krow = new Recly_Keywords('id_rss', 'keyword', '#__fdr_', 'kurss');

		foreach ($id as $elm) {

		        $row->delete($elm);
				$krow->delete($elm);

				$query = "DELETE FROM #__fdr_watched_feeds WHERE id_rss='$elm'";
				$database->setQuery($query);
				$database->query();

		}

		if ($noway) {
			mosRedirect( "index2.php?option=com_feederator&amp;task=list", $GLOBALS['_FDR_LANG']->FCNBD );
		} else {
			mosRedirect( "index2.php?option=com_feederator&amp;task=list" );
		}
	}





function show($option, $task, $rows, $pageNav, $search, $toolbar)	{
		global $my, $mosConfig_live_site;

	$_FDR_LANG = $GLOBALS['_FDR_LANG'];
	$globalVariables = new Recly_GlobalVariables('fdr_vars');		

    $caption = "RSS Feeds";

    echo $toolbar->open();
    echo $toolbar->button('publish', 'Publish', 'publish', '1');
    echo $toolbar->button('unpublish', 'Unpublish', 'unpublish', '1');
    echo $toolbar->button('new', 'New', 'new_feed_step1');

    echo $toolbar->button('delete', 'Delete', 'delete', '1');
	if ($globalVariables->get('mode') == 'premium' || $globalVariables->get('mode') == 'xrss') {
        echo $toolbar->button('import', 'Parse', 'parse', '1');
	}
    echo $toolbar->close('categories', $caption);


    $savantConf = array (
    		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/administrator/components/com_feederator/templates/",
    		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
    		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/'
    );
    $savant = new Savant2($savantConf);

    $savant->assign('search', $search);
    $savant->assign('rows', $rows);
    $savant->assign('pageNav', $pageNav);
    $savant->display('rss/main.tpl.php');

	}


?>