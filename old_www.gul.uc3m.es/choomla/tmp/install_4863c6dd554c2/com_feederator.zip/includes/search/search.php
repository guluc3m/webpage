<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( $mosConfig_absolute_path . '/components/Recly/Recly_RSS/Recly_RSS.php' );
require_once( $mosConfig_absolute_path . '/components/Recly/Recly_Search/SearchRequest.php');
require_once($mosConfig_absolute_path . '/components/Recly/common/GlobalVariables.php');
require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_HTML/Recly_Paginator.php');
require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_HTML/Recly_Toolbar.php' );

$globalVariables = new Recly_GlobalVariables('fdr_vars');

		$feed = new Recly_RSS( 'Id','#__fdr_' );
		$feed->load( $id );
		$params = new mosParameters('');

$searchTerm = mosGetParam($_REQUEST, 'searchword', null);
$idSearcher = mosGetParam($_REQUEST, 'id_user', null);

    $limit = mosGetParam($_REQUEST, 'limit', 10);	
    $limitstart = mosGetParam($_REQUEST, 'limitstart', 0);	

if (isset($idSearcher) && $idSearcher != $my->id) {
    
    $idSearcher = '';
    
}

$searchRequest = new SearchRequest();
$keywords = array();
//$page = mosGetParam($_REQUEST, 'page', 1);


//if (!empty($searchTerm)) {
   $keywords = Recly_String::tokenizeQuoted($searchTerm);
   $searchRequest->setKeywords($keywords);
   $searchRequest->setSearchTerm($searchTerm);
   $searchRequest->setFirstResultNumber(($page - 1) * 10);
   $searchResults = $feed->search($searchRequest, $idSearcher);

   $pageNav = new Recly_Paginator( sizeof($searchResults), $limitstart, $limit );
   
   
   $reclyRSS = new Recly_RSS('Id','#__fdr_');

$savantToolbarConf = array (
		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/components/com_feederator/templates/toolbar/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'template_URL' => $GLOBALS['mosConfig_live_site'] . "/components/com_feederator/templates/toolbar/"
);   

   $toolbar = new Recly_Toolbar('adminForm', $savantToolbarConf);
  
    $toolbar->enableStyles();
      
$savantConf = array (
		'template_path' => $mosConfig_absolute_path . "/components/com_feederator/templates/",
		'plugin_path' => $mosConfig_absolute_path . '/components/Recly/Savant2/',
		'filter_path' => $mosConfig_absolute_path . '/components/Recly/Savant2/'
);    
   
$savant = new Savant2($savantConf);
$savant->assign('search_request', $searchRequest);
$savant->assign('search_results', array_slice($searchResults, $limitstart, $limit));
$savant->assign('search_term', $searchTerm);
$savant->assign('limit', $limit);
$savant->assign('limitstart', $limitstart);
$savant->assign('id_user', $my->id);
$savant->assign('reclyRSS', $reclyRSS);
$savant->assign('task', mosGetParam($_REQUEST, 'task', ''));
$savant->assign('mosConfig_live_site', $mosConfig_live_site);
$savant->assign('enableWatching', $globalVariables->get('enableWatching'));
$savant->assign('pageNav', $pageNav);
$savant->display('search/main.tpl.php');
?>