<?php

require_once( $mosConfig_absolute_path . '/components/Recly/Recly_TMSP/Recly_TMSP.class.php' );

	$toolbar->enableStyles();
    echo $toolbar->open();    
    echo $toolbar->button('save', 'Save', 'save_tmsp', '0');
    echo $toolbar->button('apply', 'Apply', 'apply_tmsp', '0'); 
    echo $toolbar->button('cancel', 'Cancel', 'cancel_tmsp', '0');        
    echo $toolbar->close('static', 'Add new text messaging service provider');

		mosCommonHTML::loadOverlib();
		mosCommonHTML::loadCalendar();
		
		$_FDR_LANG = $GLOBALS['_FDR_LANG'];
		$option = $GLOBALS['option'];
		$task = $GLOBALS['task'];
		
		$lists = array();
		
		$lists['published'] = mosHTML::yesnoSelectList('published', '', 1);

		?>
		<script language=\"javascript\" type=\"text/javascript\">
		<!--
			function submitbutton(pressbutton) {
				var form = document.adminForm;
				if (pressbutton != '') {
					if (pressbutton == 'cancel') {
						submitform( pressbutton );
					} else {						
						// do field validation 
						if (form.name.value == ""){
							alert( "Item must have a name" );
						} else {
						submitform( pressbutton );
						}
					}
				}			
			}
		//-->
		</script>


		<form action="index2.php" method="post" name="adminForm">

		
		<table cellspacing="2" cellpadding="0" width="100%">		
		<tr><td width="100%" valign="top">

			<table class="adminform"><tr><th colspan="3" >
			<b><?php echo $_FDR_LANG->SETTINGS;?></b>
			</th></tr>

			<tr><td valign="top" align="right" width="20%">
			<b><?php echo $_FDR_LANG->NAME;?>
			</td><td>
			<input type="text" name="name" size="50" maxlength="255" value="" class="text_area" />
			</td><td>
			Text Messaging Service Provider
			</td>
			</tr>

			<tr><td valign="top" align="right">
			<b><?php echo $_FDR_LANG->PUBLISHED;?></b>
			</td><td colspan="2">
			<?php echo $lists['published'];?>	
			</td></tr>

			<tr><td valign="top" align="right" width="20%">
			<b><?php echo $_FDR_LANG->DOMAIN;?>
			</td><td>
			number@<input type="text" name="domain" size="40" maxlength="255" value="" class="text_area" />
			</td><td>
			Example: in number@<b>mobile.mycingular.com</b> domain is <b>mobile.mycingular.com</b>
			</td>
			</tr>
						
<!--			
			<tr><td valign="top" align="right" width="40%">
			<?php //echo $_FDR_LANG->CATEGORY;?>
			</td><td>
			<?php //echo $lists['catids'];?>
			</td></tr>
-->
			</table>

		
		</td></tr>
		</table>


		<input type="hidden" name="id" value="" />
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		
		</form><br />
		<?php
			

?>