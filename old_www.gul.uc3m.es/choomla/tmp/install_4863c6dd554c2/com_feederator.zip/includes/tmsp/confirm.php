<?php

$confirmationCode = mosGetParam($_REQUEST, 'code', null);

    	$query = "SELECT receive_notifications_confirmationcode FROM #__users WHERE id='".$my->id."'";
    	$database->setQuery( $query );
    	$savedConfirmationCode = $database->loadResult();
    	
if ($savedConfirmationCode == $confirmationCode) {
    
     $query = "UPDATE #__users SET receive_notifications_confirmed = '1' WHERE id = '$my->id'";
		
   $database->setQuery( $query );
   $database->query();  
   
   echo "You have successfully confirmed your phone number and now can receive messages!";
    
    
} else {

   echo "Sorry, wrong confirmation code!";
    
}


?>