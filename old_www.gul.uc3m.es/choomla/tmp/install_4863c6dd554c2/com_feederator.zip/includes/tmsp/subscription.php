<?php

    require_once($GLOBALS['mosConfig_absolute_path'] . '/components/Recly/common/GlobalVariables.class.php');
    
switch ( $task ) {

	case 'subscribe_tmsp':
	     subscribe(1);
      break;      
      
    case 'unsubscribe_tmsp':
	     subscribe(0);
      break; 
          
}


function subscribe($isSubscribing) {
    
$my = $GLOBALS['my'];  
$database = $GLOBALS['database'];    
$globalVariables = new Recly_GlobalVariables('fdr_vars');

$useCommunityBuilder = $globalVariables->get('useCommunityBuilder');

    	$query = "SELECT receive_notifications_confirmed FROM #__users WHERE id='".$my->id."'";
    	$database->setQuery( $query );
    	$isPhoneNumberConfirmed = $database->loadResult();

if ($isPhoneNumberConfirmed) {    
	if ($useCommunityBuilder) {   
    	$receiveNoticesFieldName = $globalVariables->get('cb_ReceiveNotices');   	
    	$query = "UPDATE #__comprofiler SET $receiveNoticesFieldName = '$isSubscribing' WHERE user_id='$my->id'";
    	
	} else {
    	$query = "UPDATE #__user SET receive_notifications = '$isSubscribing' WHERE id='$my->id'";
	    
	}
	
    	$database->setQuery( $query );
    	$database->query();	
    	
    if ($isSubscribing == '1') {
        $message = "You have been successfully subscribed to receive notices!";        
    } else {
        $message = "You have been successfully unsubscribed from receiving notices!"; 
    }	
} else {
 //$message = "Cannot subscribe/unsubscribe unconfirmed phone number!";  
 
 require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_TMSP/Recly_TMSP.class.php' );	
			 
 Recly_TMSP::sendConfirmationMessage($my->id);    
 
 $message = "Confirmation message was sent to your phone number!";  

    
}

echo $message;  
        
}



?>