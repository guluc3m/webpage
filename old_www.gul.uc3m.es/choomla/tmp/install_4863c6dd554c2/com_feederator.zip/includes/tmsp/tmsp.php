<?php

		///require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
		require_once( $mosConfig_absolute_path . '/components/Recly/Recly_HTML/Recly_Paginator.class.php' );
		require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/components/com_feederator/mainmenu.feederator.php' );
		
		require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_Keywords/Recly_Keywords.class.php');

		require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_TMSP/Recly_TMSP.class.php' );
		
		$search = mosGetParam($_REQUEST, 'search', '');		
		
		switch ($task) {
		    case 'apply_tmsp':
			case 'save_tmsp':
			    if (is_array($id)) $id = $id[0];  
			     
        		$row = new Recly_TMSP('Id','#__fdr_');

        		if ($id != '' && $id != '0') {
        		    $row->Id = $id;

        		} else {       
 

            		 $row->_tbl_key = '';
        		}
        		
        		
            		 $row->published = mosGetParam($_REQUEST, 'published', 0 );  
            		 $row->name = Preparator::prepareForSQL(mosGetParam($_REQUEST, 'name', '' )); 
            		 $row->domain = Preparator::prepareForSQL(mosGetParam($_REQUEST, 'domain', '' )); 


        		if (!$row->store()) {
        			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
        			echo $row->getError()."<hr>";
        			exit();
        		}	

        	   if ($row->Id == '') {
	             	$database->setQuery( "SELECT Id"
	            		. "\n FROM #__fdr_cellphone_providers"
	            		. "\n WHERE keywords = '$row->keywords' AND name = '$row->name'"
	            	);
	    	       $id = $database->loadResult();       	   
        	   } else {
        	   	   $id = $row->Id;
        	   }

        		
        		$msg = $row->name . $_FDR_LANG->SCSA;
        		//echo "msg=$msg<hr>";
        		//exit;
        		if ('apply_tmsp' == $task) {
        		    

    	       //print_r("id=$id"); echo "<hr>";      
    	      // echo $database->getQuery()."<hr>";
    	      // exit;   		    
        			mosRedirect( "index2.php?option=$option&amp;task=edit_tmsp&id=$id", $msg );
        		} elseif ('save_tmsp' == $task) {
        			mosRedirect( "index2.php?option=$option&amp;task=manage_tmsp", $msg );
        		}		
				
				break;
		
			case 'publish_tmsp':
			     publish( 1 );
			break;	
			
			case 'unpublish_tmsp':
			     publish( 0 );
			break;	
			
			case 'delete_tmsp':
			     delete();
			break;				
			
			default:
					$limit = $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit );
            		$limitstart = $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 );
            		$filter = "";
            		if ($search) {
            			$filter .= "WHERE name like '%$search%'";
            		}
            		
            		// get the total number of records
            		$database->setQuery( "SELECT count(*) FROM #__fdr_cellphone_providers $filter");
            		
            		$total = $database->loadResult();
            		
            		//$pageNav = new mosPageNav( $total, $limitstart, $limit );
            		$pageNav = new Recly_Paginator( $total, $limitstart, $limit ); 
            		
            		$query = "SELECT * "
            		. "\n  FROM  #__fdr_cellphone_providers "
            		. "\n $filter "
            		. "\n ORDER BY name "
            		. "\n LIMIT $pageNav->limitstart,$pageNav->limit"
            		;
            		$database->setQuery( $query );
            		$rows = $database->loadObjectList();
            
            		if ($database->getErrorNum()) {
            			echo $database->stderr();
            			return false;
            		}

			        show( $option,  $task, $rows, $pageNav, $search );
				break;
		}
		
		
	function publish( $state=0 )	{
		global $database, $my;
		
		$_FDR_LANG = $GLOBALS['_FDR_LANG'];
		$option = $GLOBALS['option'];
		$task = $GLOBALS['task'];

		$id = $GLOBALS['id'];
		$search = mosGetParam($_REQUEST, 'search', '');
		
		
	//	echo "id=";print_r($id);echo "<hr>";
   // exit;
		if (count( $id ) < 1) {
			$action = $state == 1 ? 'publish' : 'unpublish';
			echo "<script> alert('".$_FDR_LANG->SELITEM." $action'); window.history.go(-1);</script>\n";
			exit;
		}
		
		//print_r("cid=".$cid);
		//echo "count(cid)=".count( $cid )."<hr>";
		//echo "cid[0]=".$cid[0]."<hr>";
		
		$total = count ( $id );
		$cids = (count( $id ) == 1) ? $id[0] : implode( ',', $id );
	
		$query = "UPDATE #__fdr_cellphone_providers"
		. "\n SET published = $state"
		. "\n WHERE Id IN ( $cids )"
		;
		$database->setQuery( $query );
		//echo $database->getQuery()."<hr>";
		//exit;
		if (!$database->query()) {
			echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
			exit();
		}
	
	
		if ( $state == "1" ) {
			$msg = $total . $_FDR_LANG->ITEMSP;
		} else if ( $state == "0" ) {
			$msg = $total . $_FDR_LANG->ITEMSUP;
		}
		
		mosRedirect( 'index2.php?option=com_feederator&amp;task=manage_tmsp&amp;search='. $search . '&mosmsg='. $msg );
	}	
		
	function delete() {
		global $database;
		
		$option = $GLOBALS['option'];
		$task = $GLOBALS['task'];
		$id = $GLOBALS['id'];
		
		$row = new Recly_TMSP( 'Id','#__fdr_' );
		
		foreach ($id as $elm) {

				$row->delete($elm);


		}
	
		if ($noway) {
			mosRedirect( "index2.php?option=$option&amp;task=manage_tmsp", $GLOBALS['_FDR_LANG']->FCNBD );
		} else {	
			mosRedirect( "index2.php?option=$option&amp;task=manage_tmsp" );
		}	
	}		

	


	
function show($option, $task, $rows, $pageNav, $search)	{
		global $my, $mosConfig_live_site, $toolbar;
		
		$_FDR_LANG = $GLOBALS['_FDR_LANG'];
		
    $caption = "Text Messaging Service Providers";
  
    $toolbar->enableStyles();
    echo $toolbar->open();    
    echo $toolbar->button('publish', 'Publish', 'publish_tmsp', '1');   
    echo $toolbar->button('unpublish', 'Unpublish', 'unpublish_tmsp', '1');  
    echo $toolbar->button('new', 'New', 'new_tmsp');   
    //echo $toolbar->button('edit', 'Edit', 'edit_feed', '1');   
    echo $toolbar->button('delete', 'Delete', 'delete_tmsp', '1');       
    echo $toolbar->close('categories', $caption);
		
    
  
$savantConf = array (
		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/administrator/components/com_feederator/templates/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/'
);
$savant = new Savant2($savantConf);    
    
    
    $savant->assign('limit', $limit);
    $savant->assign('limitstart', $limitstart);
    $savant->assign('search', $search);
    $savant->assign('rows', $rows);
    $savant->assign('pageNav', $pageNav);
    //$savant->assign('formName', '');
    $savant->display('tmsp/main.tpl.php');	  
    

	}


?>