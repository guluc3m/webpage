<?php

/**
* Feederator - RSS Mananagement System for Joomla CMS
* @version 1.0
* @package Feederator
* @author Anton Nikiforov (st@recly.com)
* @copyright (C) 2008 by Recly Interactive - All rights reserved, http://www.recly.com
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once($GLOBALS['mosConfig_absolute_path']. '/administrator/components/com_feederator/Recly_Config.php');


function com_install() {

	# Perform fresh install
	return new_install();

}

function copyFile ($class, $extension) {

    	        $copyFrom = $GLOBALS['mosConfig_absolute_path'] . '/administrator/components/com_feederator/Recly/'.$class[1].'/'.$class[0].$extension;
    	        $copyTo = $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/'.$class[1].'/'.$class[0].$extension;
    	        return copy($copyFrom, $copyTo);
}

function createIndexHTML ($folder) {
    
    	    $fp = fopen( $folder . "/index.html", "w" );
			fwrite( $fp, "<html>\n<body bgcolor=\"#FFFFFF\">\n</body>\n</html>" );
			fclose( $fp );
			return mosChmod( $folder."/index.html" );    
    
}

function addColumnIfNotExists($name, $table, $type = 'int(1) unsigned NOT NULL DEFAULT \'0\'') {   
    global $database;
    
	$query = "SHOW columns FROM $table";
	$database->setQuery($query);
	$rows = $database->loadObjectList();
	$exists = false;
	foreach ($rows as $row) {
		if ($row->Field == $name) $exists = true;
	}
    if (!$exists) {
    	$database->setQuery("ALTER TABLE `$table` ADD COLUMN `$name` $type");
    	$database->query();        
    }     

}

function new_install() {
	global $database, $mosConfig_mailfrom, $mosConfig_live_site, $mosConfig_absolute_path;

	require_once($mosConfig_absolute_path . '/administrator/components/com_feederator/includes/about/about_welcome.php');
	
	$msg .= '<table width="100%" border="0" cellpadding="8" cellspacing="0">';
    $msg .= '<tr><td align="left" valign="top">';
	
	# Change icon in admin menu
	$database->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_feederator/images/icon.gif' WHERE admin_menu_link='option=com_feederator'");
	$database->query();
	
	$query = "SELECT COUNT(*) FROM #__menu WHERE link = 'index.php?option=com_feederator&task=list_feeds'";
	$database->setQuery($query);
	if (!$database->loadResult()) {	
    	# Add a menu item to usermenu
    	$database->setQuery("INSERT INTO #__menu (`menutype`,`name`,`link`,`type`,`published`,`parent`,`componentid`,`sublevel`,`ordering`,`checked_out`,`checked_out_time`,`pollid`,`browserNav`,`access`,`utaccess`,`params`) VALUES ('usermenu','My RSS Feeds','index.php?option=com_feederator&task=list_feeds','url',1,0,0,0,6,0,'0000-00-00 00:00:00',0,0,0,0,'menu_image=-1')");
    	$database->query();	
	}
	
	addColumnIfNotExists('orderby', '#__fdr_feeds', 'varchar(50) NULL');
	addColumnIfNotExists('ordering_direction', '#__fdr_feeds', 'varchar(4) NULL DEFAULT \'DESC\'');
	addColumnIfNotExists('count', '#__fdr_feeds', 'int(5) unsigned NOT NULL DEFAULT \'5\'');
	addColumnIfNotExists('show_full', '#__fdr_feeds', 'int(1) unsigned NOT NULL DEFAULT \'0\'');
	addColumnIfNotExists('limit_text', '#__fdr_feeds', 'int(1) unsigned NOT NULL DEFAULT \'0\'');
	
    $classes = array(
                    array( "Savant2", "", 0),
                    array( "String", "common", 1),
                    array( "GlobalVariables", "common", 1),                   
                    array( "getid3", "getid3", 0),
                    array( "getid3.lib", "getid3", 0),
                    array( "module.audio.mp3", "getid3", 0),
                    array( "module.tag.apetag", "getid3", 0),
                    array( "module.tag.id3v1", "getid3", 0),
                    array( "module.tag.id3v2", "getid3", 0),
                    array( "module.tag.lyrics3", "getid3", 0),
                    array( "Recly_Paginator", "Recly_HTML", 1),
                    array( "Recly_Toolbar", "Recly_HTML", 1),
                    array( "Recly_HTML", "Recly_HTML", 1),
                    array( "Recly_Keywords", "Recly_Keywords", 1),  
                    array( "Recly_RSSParser", "Recly_RSS", 1),                 
                    array( "Recly_RSS", "Recly_RSS", 1),
                    array( "Recly_RSS2DB", "Recly_RSS", 1),
                    array( "feedcreator", "Recly_RSS", 1),    
                    array( "SearchRequest", "Recly_Search", 1), 
                    array( "Recly_Table", "Recly_Table", 1),
                    array( "simplepie.inc", "simplepie", 0),
                    array( "sp_compatibility_test", "simplepie", 0),
                    array( "Error", "Savant2", 0),
                    array( "Filter", "Savant2", 0),
                    array( "Plugin", "Savant2", 0),
                    array( "Savant2_Compiler_basic", "Savant2", 0),
                    array( "Savant2_Error_exception", "Savant2", 0),
                    array( "Savant2_Error_pear", "Savant2", 0),
                    array( "Savant2_Error_stack", "Savant2", 0),
                    array( "Savant2_Filter_colorizeCode", "Savant2", 0),
                    array( "Savant2_Filter_trimwhitespace", "Savant2", 0),
                    array( "Savant2_Plugin_ahref", "Savant2", 0),
                    array( "Savant2_Plugin_checkbox", "Savant2", 0),
                    array( "Savant2_Plugin_cycle", "Savant2", 0),
                    array( "Savant2_Plugin_dateformat", "Savant2", 0),
                    array( "Savant2_Plugin_form", "Savant2", 0),
                    array( "Savant2_Plugin_image", "Savant2", 0),
                    array( "Savant2_Plugin_input", "Savant2", 0),
                    array( "Savant2_Plugin_javascript", "Savant2", 0),
                    array( "Savant2_Plugin_modify", "Savant2", 0),
                    array( "Savant2_Plugin_options", "Savant2", 0),
                    array( "Savant2_Plugin_stylesheet", "Savant2", 0)
                    );	

	$config = new Recly_Config();
	
    $msg .= $config->install($classes, 'com_feederator', 'Feederator');

	$msg .='<br /><br /></td></tr></table>';

	return $msg ;
} 



?>
