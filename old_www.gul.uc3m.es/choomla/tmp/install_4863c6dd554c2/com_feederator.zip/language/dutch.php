<?php

class FDRLanguage {
	
var $ERROR = 'FOUT: ';	
var $YES = 'Ja';	
var $NO = 'Nee';	
var $CANCEL = 'Stoppen';
var $HIDE = 'Verberg';
var $SHOW = 'Laat zien';
var $USEGLOBAL = 'Gebruik Globaal';

var $KEYWORDS = 'Kernwoorden';
var $NAME = 'Naam';
var $URL = 'URL';
var $PUBLISHED = 'Gepubliceerd';
var $UNPUBLISHED = 'Ongepubliceerd';
var $ID = 'Id';
var $ITEM = 'Item';

var $DOMAIN = 'Domein';

var $ABOUT = 'Over';
var $SETTINGS = 'Instellingen';
var $STATISTICS = 'Statistieken';
var $PARAMETERS = 'Parameters';
var $CATEGORIES = 'Categorie&euml;n';
var $MAIN_MENU = 'Hoofd Menu';
var $UPDATE_CLASSES = 'Update Classes';


var $RSS_FEEDS = 'RSS Feeds';
var $ADD_RSS_FEED = 'Toevoegen RSS Feed';
var $EDIT_INTERNAL_RSS_FEED = 'Wijzig Interne RSS Feed';
var $EDIT_EXTERNAL_RSS_FEED = 'Wijzig Externe RSS Feed';
var $EDIT_COMPILED_RSS_FEED = 'Wijzig Gecompileerde RSS Feed';

var $CACHE_ENABLED = 'Cache Aangezet';
var $CACHE_TIMEOUT = 'Cache Timeout, sec';
var $MANAGE_FEEDS = 'Manage Feeds';
var $NUMBER_OF_FEEDS = 'Aantal Feeds';

var $SELITEM = 'Selecteer een item naar';
var $ITEMSP = 'Item(s) succesvol gepubliceerd';
var $ITEMSUP = 'Item(s) succesvol ongepubliceerd';
var $ALLCATS = 'Alle Categorie&euml;n';
var $TI = 'Het item';
var $EAA = ' word momenteel gewijzigd door een andere administrator';
var $SCSA = ' succesvol Opgeslagen';
var $TMSP = 'Tekst Berichtendienst Service Aanbieders';
var $TMS_P = 'TMS Aanbieders';
var $FCNBD = 'VOORPAGINA KAN NIET WORDEN VERWIJDERD';

	
}

$GLOBALS['_FDR_LANG'] = new FDRLanguage();

?>