<?php 

defined( '_VALID_MOS' ) or die( 'Restricted access' );

$i = $this->i;
$row = $this->row;
$pageNav = $this->pageNav;

?>
<table width="100%" cellpadding="0" cellspacing="0" border="0" >
   <tr>
      <td>
         <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
               <td style="text-align:left;" rowspan="2" valign="top" width="20">
<?php echo $i+1+$pageNav->limitstart;?>.
              </td>
               <td style="text-align:left;" rowspan="2" valign="middle" width="20">
 <?php

			switch ($row['format']) {
			 case 'RSS2.0':
			     $formatImage = "<a href=\"javascript:void(0)\" onClick=\"window.open('".$GLOBALS['mosConfig_live_site'].'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row['id']."','','')\"><img src=\"".$GLOBALS['mosConfig_live_site']."/components/com_feederator/images/rssfeedicon.gif\" alt=\"Click here to view as ".$row['format']."\" border=\"0\"></a>";
			 break;
			 
			 case 'iTunesDTD2.0':
			     $formatImage = "<a href=\"javascript:void(0)\" onClick=\"window.open('".$GLOBALS['mosConfig_live_site'].'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row['id']."','','')\"><img src=\"".$GLOBALS['mosConfig_live_site']."/components/com_feederator/images/itunesfeedicon.gif\" alt=\"Click here to view as ".$row['format']."\" border=\"0\"></a>";
			 break;			    
			     $formatImage = "(<a href=\"javascript:void(0)\" onClick=\"window.open('".$GLOBALS['mosConfig_live_site'].'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row['id']."','','')\">".$row['format']."</a>)";
			}

			echo $formatImage;
?>

              </td>              
              <td style="text-align:left;">
<strong><a href="<?php echo $this->mosConfig_live_site . '/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row['id'];?>"><?php echo $row['name']?></a>
<?php 
if ($this->enableWatching) {
    if (!$this->reclyRSS->isFeedWatchedByUser($row['id'], $this->id_user)) {
        echo "&nbsp;(<a href=\"".$this->mosConfig_live_site . '/index.php?option=com_feederator&amp;task=watch&amp;searchword='.$this->search_term.'&amp;id='.$row['id']."\">watch</a>)";   
    } else {
        echo "&nbsp;(<a href=\"".$this->mosConfig_live_site . '/index.php?option=com_feederator&amp;task=stop_watching&amp;searchword='.$this->search_term.'&amp;id='.$row['id']."\">stop watching</a>)";       
    }
}

?>
</strong>
               </td>
            </tr>
            <tr>
               <td style="color:#11aa11;text-align:left;">
               <i>
                <?php 
                if ($row['numberOfKeywords']>1) {
                 echo "<b>Keywords:</b>&nbsp;";   
                }
                if ($row['numberOfKeywords']==1) {
                 echo "<b>Keyword:</b>&nbsp;";   
                }                
                for ($k = 0; $k < $row['numberOfKeywords'];$k++) {
                    echo $row[$k];
                    if ($k < ($row['numberOfKeywords'])-1) echo ', ';
                }
                ?>
                </i>
               </td>
            </tr>            
         </table>      
      </td>
   </tr> 
   <tr>
      <td>
<br>
      </td>
   </tr>   
</table>