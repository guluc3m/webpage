<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
?>
<td class="toolbar_button" id="toolbar-<?php echo $this->type;?>">
<a class="toolbar" href="
     <?php 
     if ('1' == $this->alert) {
         echo "javascript:if (document.$this->formName.boxchecked.value == 0){ alert('Please select at least one item'); } else {submitbutton('$this->action');}\">";
     } else {
         echo "javascript:submitbutton('$this->action');\">";
     }
     ?>
<div class="icon-32-<?php echo $this->type;?>" title="<?php echo $this->title;?>" type="Standard">
</div>
<?php echo strtoupper($this->title);?>
</a>
</td>