<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
?>
</tr></table>
</div>   

<div class="header icon-48-<?php echo $this->type;?>">
&nbsp;<?php echo $this->title;?>
</div>

										<div class="clr"></div>

								</div>
								<div class="clr"></div>
							</div>

<div class="spacer"></div>
