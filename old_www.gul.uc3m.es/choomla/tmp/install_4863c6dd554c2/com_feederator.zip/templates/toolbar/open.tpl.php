<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );     
?>       
        <script type="text/javascript">
        
        function saveorder( n ) {
        	checkAll_button( n );
        }
        
        //needed by saveorder function
        function checkAll_button( n ) {
        	for ( var j = 0; j <= n; j++ ) {
        		box = eval( "document.adminForm.cb" + j );
        		if ( box ) {
        			if ( box.checked == false ) {
        				box.checked = true;
        			}
        		} else {
        			alert("<?php echo 'CANNOT_CHANGE_WORDS_ORDER'; ?>");
        			return;
        		}
        	}
        	submitform('saveorder');
        }
        
        </script>         
	


<div class="toolbar-box">
  <div class="toolbar-pad">
  	<div class="toolbar" id="toolbar">
    <table class="toolbar"><tr>   

