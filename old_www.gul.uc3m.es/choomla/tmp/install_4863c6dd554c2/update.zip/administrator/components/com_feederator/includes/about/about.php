<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Recly_HTML/Recly_Toolbar.php' );

   $toolbar = new Recly_Toolbar('adminForm', array (
		'template_path' => $GLOBALS['mosConfig_absolute_path'] . "/components/com_feederator/templates/toolbar/",
		'plugin_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'filter_path' => $GLOBALS['mosConfig_absolute_path'] . '/components/Recly/Savant2/',
		'template_URL' => $GLOBALS['mosConfig_live_site'] . "/components/com_feederator/templates/toolbar/"
));
    //$toolbar->enableStyles();
    echo $toolbar->open();
    echo $toolbar->close('google', 'About Feederator');

   ?>
<form action="index2.php" method="post" name="adminForm">
		<input type="hidden" name="id" value="0" />
		<input type="hidden" name="option" value="com_feederator" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="hidemainmenu" value="0" />
</form>

<?php

$msg = '<div align="left"><table border="0" cellpadding="8" cellspacing="0"><tr><td align="center" valign="top"><center><img src="'.$mosConfig_live_site.'/administrator/components/com_feederator/images/logo.jpg" alt="Feederator" />
<br />
&copy; 2008 <a href="http://www.recly.com">Recly Interactive, LLC</a>

</center></td>';
$msg .= '<td align="left" valign="top">';
$msg .= $savant->fetch('about.tpl.php');
$msg .= '</td>
</tr></table></div>';


echo $msg;


?>