<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

$msg = '<div align="left">
<table border="0" cellpadding="8" cellspacing="0">
<tr>
<td align="center" valign="top">
<center><h1 style="color:#9FB351">Welcome to Feederator!</h1></center><br />
<center><img src="'.$mosConfig_live_site.'/administrator/components/com_feederator/images/logo_welcome.jpg" alt="Feederator" />
<br />
&copy; 2008 <a href="http://www.recly.com">Recly Interactive, LLC</a>

</center></td>
</tr></table></div>';

?>