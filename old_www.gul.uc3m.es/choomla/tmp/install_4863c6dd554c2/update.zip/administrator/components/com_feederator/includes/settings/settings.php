<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once($mosConfig_absolute_path.'/components/Recly/common/String.php');
//require_once($mosConfig_absolute_path.'/components/Recly/common/WebVariables.php');
require_once($mosConfig_absolute_path . '/components/Recly/common/GlobalVariables.php');

$globalVariables = new Recly_GlobalVariables('fdr_vars');
$globalTextVariables = new Recly_GlobalVariables('fdr_text_vars');
//$toolbar->enableStyles();
    echo $toolbar->open();
    echo $toolbar->button('save', 'Save', 'savesettings', '0');
    echo $toolbar->button('apply', 'Apply', 'applysettings', '0');
    echo $toolbar->button('cancel', 'Cancel', 'cancel', '0');
    echo $toolbar->close('addons', 'Settings');


switch ($task) {

	case "savesettings":
	case "applysettings":
		updateSettings();
		break;
}


$notificationText = Recly_Preparator::prepareForDisplay($globalTextVariables->get('tmspMessage'));
$tmspTextMessage = Recly_Preparator::prepareForDisplay($globalTextVariables->get('tmspTextMessage'));
$tmspEachRSSMessage = Recly_Preparator::prepareForDisplay($globalTextVariables->get('tmspEachRSSMessage'));
$tmspEachRSSTextMessage = $globalTextVariables->get('tmspEachRSSTextMessage');
$tmspConfirmationTextMessage = $globalTextVariables->get('tmspConfirmationTextMessage');
$stopWords = $globalTextVariables->get('stopWords');
$parsedTags = $globalTextVariables->get('parsedTags');



$lists['send_emails'] = mosHTML::yesnoSelectList('sendEmails', '', $globalVariables->get('sendEmails'));

$lists['useCommunityBuilder'] = mosHTML::yesnoSelectList('useCommunityBuilder', '', $globalVariables->get('useCommunityBuilder'));
$lists['enableBookmarking'] = mosHTML::yesnoSelectList('enableBookmarking', '', $globalVariables->get('enableBookmarking'));


 ?>

      <FORM action="<?php echo "index2.php?option=$option";?>" method=post name="adminForm">
      <input type="hidden" name="task" value="">

		<table cellpadding="3" cellspacing="0" border="0" width="100%">
			<tr>
				<td width="" class="tabpadding">&nbsp;</td>
				<td id="tab1" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo 'General'; ?></td>
				<td id="tab2" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo 'Integration'; ?></td>
				<?php
				if ($globalVariables->get('mode') == 'xrss') {
				    ?>
				<td id="tab3" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo 'Alerts'; ?></td>
				<?php } ?>
				<td width="80%" class="tabpadding">&nbsp;</td>
			</tr>
		</table>



<div id="page1" class="pagetext">

 	<table cellspacing="0" cellpadding="0" width="100%">
	<tr>
		<td width="80%" valign="top">

		<table cellpadding="2" cellspacing="1" border="0" width="100%" class="adminform">
			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Delete parsed items every'; ?></b>:<br/>
				<?php
				$isDisabled = '';
				if ($globalVariables->get('mode') == 'demo') {
				    $isDisabled = 'disabled';
				    ?>
				<font color="#FF0000">Only in the Premium version</font>
				<?php } ?>
				</td>
				<td width="40%" align="left">
				<input type="text" name="deleteParsedItemsEveryNumberOfDays" value="<?php echo $globalVariables->get('deleteParsedItemsEveryNumberOfDays');?>" size="3" maxlength="3"  <?php echo $isDisabled;?>/>&nbsp;days

				</td>
				<td width="30%" align="left">

					Choose a period after which all previously parsed RSS items will be deleted

				</td>
			</tr>



			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Stop words';// (text form) ?></b>:</td>
				<td width="40%" align="left" >
				<textarea name="stopWords" cols="40" rows="10"><?php echo $stopWords;?></textarea>
				</td>
				<td width="30%" align="left">
					Stop words to be excluded from keywords
				</td>
			</tr>


			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'List of tags to parse for keywords';// (text form) ?></b>:<br/>
				<?php
				$isDisabled = '';
				if ($globalVariables->get('mode') == 'demo') {
				    $isDisabled = 'disabled';
				    ?>
				<font color="#FF0000">Only in the Premium version</font>
				<?php } ?>
				</td>
				<td width="40%" align="left" >
				<textarea name="parsedTags" cols="40" rows="10" <?php echo $isDisabled;?>><?php echo $parsedTags;?></textarea>
				</td>
				<td width="30%" align="left">
					When you click "Parse" button in "Manage Feeds" section, Feederator parses selected feeds and saves their content to the database.
					For each item, Feederator generates relevant keywords based on the contents of the tags listed here.
				</td>
			</tr>
        </table>
		</td>
	</tr>
	</table>

</div>
<div id="page2" class="pagetext">

 	<table cellspacing="0" cellpadding="0" width="100%">
	<tr>
		<td width="80%" valign="top">

		<table cellpadding="2" cellspacing="1" border="0" width="100%" class="adminform">

<?php /*
			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Do you use Community Builder?'; ?></b>:</td>
				<td width="40%" align="left">
				<?php echo $lists['useCommunityBuilder']; ?>
				</td>
				<td width="30%" align="left">

					Select Yes if you use Community Builder to store users' information

				</td>
			</tr>
*/?>
			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Enable SocioTag?'; ?></b>:</td>
				<td width="40%" align="left">
				<?php echo $lists['enableBookmarking']; ?>
				</td>
				<td width="30%" align="left">

					Select Yes to allow users bookmark individual items of external RSS feeds. <b>Please note</b>: you need to have SocioTag mambot installed to enable this feature. You can <a href="http://www.socioclick.com/Social-Bookmarking/SocioTag-Premium-Joomla-1.0v.html">download it here</a>.

				</td>
			</tr>





        </table>

        </td>
     </tr>
     </table>

</div>
				<?php
				if ($globalVariables->get('mode') == 'xrss') {
				    ?>
<div id="page3" class="pagetext">

 	<table cellspacing="0" cellpadding="0" width="100%">
	<tr>
		<td width="80%" valign="top">

		<table cellpadding="2" cellspacing="1" border="0" width="100%" class="adminform">
			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Send notifications'; ?></b>:</td>
				<td width="40%" align="left">
				<?php echo $lists['send_emails']; ?>
				</td>
				<td width="30%" align="left">

					Notify users when rss feeds updated
				</td>
			</tr>

			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Notify users about RSS feeds updated within last'; ?></b>:</td>
				<td width="40%" align="left">
				<input type="text" name="numberOfHoursRSSConsideredToBeNew" value="<?php echo $globalVariables->get('numberOfHoursRSSConsideredToBeNew');?>" size="3" maxlength="3"/>&nbsp;hours

				</td>
				<td width="30%" align="left">

					Feederator checks if the feeds were updated not earlier than that number of hours back, and if they were, will notify users

				</td>
			</tr>

			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Title of notification message'; ?></b>:</td>
				<td width="40%" align="left">

					<input type="text" name="titleNotificationMessage" value="<?php echo $globalVariables->get('titleNotificationMessage');?>" size="50"/>
				</td>
				<td width="30%" align="left">

					Title of Notification Message
				</td>
			</tr>

			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Notification message';// (text form) ?></b>:</td>
				<td width="40%" align="left" >
				<textarea name="tmspTextMessage" cols="40" rows="10"><?php echo $tmspTextMessage;?></textarea>
				</td>
				<td width="30%" align="left">

					This message will be sent to users. The following tags can be used:<br>
					<b>[USERNAME], [RSS_FEEDS], [SITENAME]</b>
				</td>
			</tr>

			<tr valign="top">
				<td width="30%" align="right"><b><?php echo '[RSS_FEEDS] item in Notification message';//(text form) ?></b>:</td>
				<td width="40%" align="left" >
				<textarea name="tmspEachRSSTextMessage" cols="40" rows="10"><?php echo $tmspEachRSSTextMessage;?></textarea>
				</td>
				<td width="30%" align="left">

					Here you can define how each individual RSS feed will be represented in [RSS_FEEDS] list <br>
					You can use the following tags: <b>[URL], [NAME], [NAME_URL], [PIN], [PHONE]</b>
				</td>
			</tr>

			<tr valign="top">
				<td width="30%" align="right"><b><?php echo '[PHONE]'; ?></b>:</td>
				<td width="40%" align="left">

					<input type="text" name="phonePIN" value="<?php echo $globalVariables->get('phonePIN');?>" size="50"/>
				</td>
				<td width="30%" align="left">

					Define what phone number will replace [PHONE] tag
				</td>
			</tr>


			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Title of Subscription Confirmation Message'; ?></b>:</td>
				<td width="40%" align="left">

					<input type="text" name="titleConfirmationMessage" value="<?php echo $globalVariables->get('titleConfirmationMessage');?>" size="50"/>
				</td>
				<td width="30%" align="left">

					Title of Subscription Confirmation Message
				</td>
			</tr>

			<tr valign="top">
				<td width="30%" align="right"><b><?php echo 'Subscription Confirmation Message';//(text form) ?></b>:</td>
				<td width="40%" align="left" >
				<textarea name="tmspConfirmationTextMessage" cols="40" rows="10"><?php echo $tmspConfirmationTextMessage;?></textarea>
				</td>
				<td width="30%" align="left">

					After a user subscribes to receive notifications, this message containing a 4-digit confirmation code [CODE] is sent out.<br>
					You can use the following tags: <b>[CODE]</b>
				</td>
			</tr>

        </table>

        </td>
     </tr>
     </table>
    </div>
				<?php
				}
				    ?>
		<script language="javascript" type="text/javascript">dhtml.cycleTab('tab1');</script>

 </FORM>


<?php

function updateSettings() {

   $globalVariables = new Recly_GlobalVariables('fdr_vars');
   $globalTextVariables = new Recly_GlobalVariables('fdr_text_vars');

   $task = $GLOBALS['task'];

   $arr = array(
   "titleNotificationMessage" => array(
                                        "type" => "var",
                                        "default" => "Notification"),
   "titleConfirmationMessage" => array(
                                        "type" => "var",
                                        "default" => "Confirmation"),
   "phonePIN" => array(
                                        "type" => "var",
                                        "default" => ""),
   "sendEmails" => array(
                                        "type" => "var",
                                        "default" => "0"),
   "useCommunityBuilder" => array(
                                        "type" => "var",
                                        "default" => "0"),
   "enableBookmarking" => array(
                                        "type" => "var",
                                        "default" => "0"),
   "deleteParsedItemsEveryNumberOfDays" => array(
                                        "type" => "var",
                                        "default" => "1"),
   "numberOfHoursRSSConsideredToBeNew" => array(
                                        "type" => "var",
                                        "default" => "1"),
   "stopWords" => array(
                                        "type" => "text",
                                        "default" => ""),
   "tmspTextMessage" => array(
                                        "type" => "text",
                                        "default" => ""),
   "tmspEachRSSTextMessage" => array(
                                        "type" => "text",
                                        "default" => ""),
   "tmspConfirmationTextMessage" => array(
                                        "type" => "text",
                                        "default" => ""),
   "parsedTags" => array(
                                        "type" => "text",
                                        "default" => ""),
                                        );

   foreach ($arr as $k=>$v) {
      $temp = mosGetParam($_REQUEST, $k, $v['default']);
      if ($v['type'] == 'text') {
         // echo "temp=";print_r($temp);echo "<hr>";
          $temp = trim($temp);
          $globalTextVariables->set($k, $temp);
      } else if($v['type'] == 'var') {
          $globalVariables->set($k, $temp);
      }
   }


   if ('applysettings' == $task) {
        mosRedirect( "index2.php?option=com_feederator&task=settings", "Settings updated");
   } else {
        mosRedirect( "index2.php?option=com_feederator", "Settings updated");
   }

}


?>