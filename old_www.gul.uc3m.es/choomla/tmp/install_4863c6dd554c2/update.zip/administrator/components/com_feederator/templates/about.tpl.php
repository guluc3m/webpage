<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
?>
<style type="text/css">

p{
margin: 0;
padding: 5px;
line-height: 1.5em;
text-align: justify;
border: 1px solid #DDE1E6;
}
#wrapperAbout{
width: 500px;
margin: 0 auto;
}
.boxAbout{
background: #fff;
}
.boxholder{
clear: both;
padding: 5px;
background: #F1F3F5;
}
.tabAbout{
float: left;
height: 32px;
width: 102px;
margin: 0 1px 0 0;
text-align: center;
background: #F1F3F5 url(../administrator/components/com_feederator/images/graytab.jpg) no-repeat;
}
.tabtxt{
margin: 0;
color: #fff;
font-size: 12px;
font-weight: bold;
padding: 9px 0 0 0;
}
</style>
<script type="text/javascript" src="../administrator/components/com_feederator/includes/js/prototype.lite.js"></script>
<script type="text/javascript" src="../administrator/components/com_feederator/includes/js/moo.fx.js"></script>
<script type="text/javascript" src="../administrator/components/com_feederator/includes/js/moo.fx.pack.js"></script>
<script type="text/javascript">
function init(){
	var stretchers = document.getElementsByClassName('boxAbout');
	var toggles = document.getElementsByClassName('tabAbout');
	var myAccordion = new fx.Accordion(
		toggles, stretchers, {opacity: false, height: true, duration: 600}
	);
	//hash functions
	var found = false;
	toggles.each(function(h3, i){
		var div = Element.find(h3, 'nextSibling');
			if (window.location.href.indexOf(h3.title) > 0) {
				myAccordion.showThisHideOpen(div);
				found = true;
			}
		});
		if (!found) myAccordion.showThisHideOpen(stretchers[0]);
}
</script>

<div id="wrapperAbout">
	<div id="content">
	<h3 class="tabAbout" title="first"><div class="tabtxt"><a href="#">general info</a></div></h3>
	<div class="tabAbout"><h3 class="tabtxt" title="second"><a href="#">recipes</a></h3></div>
	<div class="tabAbout"><h3 class="tabtxt" title="third"><a href="#">changelog</a></h3></div>
	<div class="tabAbout"><h3 class="tabtxt" title="fourth"><a href="#">about</a></h3></div>
	<div class="boxholder">
	
		<div class="boxAbout">
			<p><strong>General Information</strong><br />
			Feederator is an RSS manager with a number of features. 
			It allows to add multiple RSS feeds to your website, mark them with keywords and pull just relevant articles out to the feed.
			With Feederator you can parse 3d-party RSS feeds and create mashups, i.e. combine multiple feeds into a single feed. 
			Users of your website would have a chance of creating personalized RSS feeds with relevant information.			
			<br /><br />
			<strong>How to upgrade</strong><br />
			Here we will be publishing instructions on how to upgrade Feederator to the latest version. In the meantime, <a href="index2.php?option=com_feederator&task=install">you can check</a> if you have the latest versions of Recly Classes.
			<br /><br />
			<strong>Support</strong><br />
			Should you have any questions, feel free to visit our <a href="http://www.recly.com/index.php?option=com_fireboard&Itemid=54&func=showcat&catid=2">Support Forum</a>.
			<br /><br />
			<strong>How can you help</strong><br />
			The best way to help us is an intensive usage of this extension! The more people use Feederator, the more stable and feature-reach will it be. If you like our work, please show your support 
			by rating or commenting on this extension at the official <a target="_blank" href="http://extensions.joomla.org/">Joomla! Extensions</a> website. 
			<br /><br />
			<strong>Credits</strong><br />
			We would like to thank <a href="http://www.nyokiglitter.com">Nyokiglitter studio</a> for the <a href="http://www.nyokiglitter.com/tutorials/tabs.html">Tab Styled Accordion</a>
			<br /><br />
			<div align="center" class="smallgrey">
Official webpage - <a href="http://www.feederator.com">http://www.feederator.com</a><br>
Created by Anton Nikiforov, contactable at <a href="mailto:st@recly.com">st@recly.com</a>.<br> 
Copyright &copy; 2008 - Feederator is a produce of Recly Interactive, LLC. - All Rights Reserved.<br> 
All trademarks and trade names are the property of their respective owners.
</div>			
			</p>			
		</div>
		
		<div class="boxAbout">
			<p><strong>Recipe Book</strong><br />
			There are many different ways to use Feederator on your website. For the inspiration, check out our <a href="http://www.recly.com/index.php?option=com_content&view=section&id=6&Itemid=65">"Recipe Book"</a>, regularly updated with new delicious recepies - from our chef:
			<br />
			<li><a href="http://www.recly.com/index.php?view=article&catid=34%3Arsspodcasting&id=54%3Afeederatorpodcasts&option=com_content&Itemid=65">How can I insert RSS feed or podcast inside a content item?</a><br />
			<li><a href="http://www.recly.com/index.php?view=article&catid=34%3Arsspodcasting&id=53%3Afeeds-personalization&option=com_content&Itemid=65">Feeds personalization</a><br />
			You may also want to now <a href="http://www.recly.com/index.php?option=com_content&view=article&id=48&Itemid=64">how to rebroadcast existing 3d-party RSS feed or podcast</a> or <a href="http://www.recly.com/index.php?option=com_content&view=article&id=48&Itemid=64">create multiple RSS feeds or podcasts with items filtered by topic</a>
			
			</p>
		</div>
		<div class="boxAbout">
			<p><strong>Changelog</strong><br />
<strong>Version 1.0.3 (June 11th, 2008). New settings for internal feeds</strong>: 
<li>option to choose if you want to display full articles or just limited number of words</li>
<li>a setting that controls ordering of RSS items</li>
<li>you can set a number of RSS items to display</li>
<br /><br />			
<strong>Version 1.0.2 (May 30th, 2008)</strong>: 
<li>some minor bug fixes</li><br /><br />			
<strong>Version 1.0.1 (May 28th, 2008)</strong>: 
<li>some minor bug fixes</li> 	
<li>Fpod bot special edition, for Joomla 1.5.xx legacy mode</li>	
<li>Dutch translation</li>	
<strong>Version 1.0.0 was released (May 19th, 2008)</strong>
			</p>
		</div>
		<div class="boxAbout">
			<p><strong>About</strong><br />
			<strong>Feederator</strong> is a <strong>Joomla!</strong> CMS extension developed by <a target="_blank" title="Visit Recly!" href="http://www.recly.com">Recly Interactive (www.recly.com)</a> and released under the <a target="_blank" title="GNU General Public License" href="http://www.gnu.org/copyleft/gpl.html">GNU General Public License</a>.
			<br /><br />
			Recly Interactive develops custom scripts and Joomla! extensions. We specialize in niche search engines and social networking websites. Would like to hire us for your project? Please <a href="mailto:support@recly.com">contact us</a> to discuss the details.
			    
			</p>
			
		</div>
	</div>
</div>
</div>
<script type="text/javascript">
	Element.cleanWhitespace('content');
	init();
</script>
