<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
?>
<table cellpadding="2" cellspacing="0" border="0" width="160" height="100%" align="left" >
<tr>
<td width="100%">
<div id="content-box2">
    <div id="content-pad">
        <div class="sidemenu-box">
            <div class="sidemenu-pad">
            
                <div class="sidemenu">
                <h3 class="title-smenu" title="aliases"><?php echo $GLOBALS['_FDR_LANG']->MAIN_MENU; ?></h3>
                    <div class="section-smenu">
                        <ul>
                        <li class="item-smenu icon-16-import">
                        <a href="javascript:submitbutton('manage_feeds')"><?php echo $GLOBALS['_FDR_LANG']->MANAGE_FEEDS; ?></a>
                        </li>
<?php /*
                        <li class="item-smenu icon-16-import">
                        <a href="javascript:submitbutton('manage_tmsp')"><?php echo $GLOBALS['_FDR_LANG']->TMS_P; ?></a>
                        </li>   
*/ ?>
                        <li class="item-smenu icon-16-cpanel">
                        <a href="javascript:submitbutton('settings')"><?php echo $GLOBALS['_FDR_LANG']->SETTINGS; ?></a>
                        </li>        
                        <?php
                        if ($this->feederator_mode != 'xrss') {
                        ?>
                        <li class="item-smenu icon-16-info">
                        <a href="javascript:submitbutton('about')"><?php echo $GLOBALS['_FDR_LANG']->ABOUT; ?></a>
                        </li>
                        <?php 
                         } 
                        ?>   
                        <li class="item-smenu icon-16-cpanel">
                        <a href="javascript:submitbutton('install')"><?php echo $GLOBALS['_FDR_LANG']->UPDATE_CLASSES; ?></a>
                        </li>                           
                        </ul>
                    </div>
                </div>
                       
                <div class="status-divider"></div>
            
                <div class="sidemenu">
                <h3 class="title-smenu" title="aliases"><?php echo $GLOBALS['_FDR_LANG']->STATISTICS; ?></h3>
                    <div class="section-smenu">
                    <table>
                    
                    				<tr>
                    					<td align="left" style="background-color:#DDE1E6" colspan="2"><b><?php echo $GLOBALS['_FDR_LANG']->NUMBER_OF_FEEDS; ?>:</b></td>
                    					<td align="center" style="background-color:#DDE1E6" ><?php echo $this->numberOfFeeds?></td>
                    				</tr>	
                    </table>
                    </div>
                </div>
            
            </div>
        </div>
    </div>
</div>
</tr>
</td>
</table>

