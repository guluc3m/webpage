<script language="Javascript">
function submitAdminForm1(task){
  document.adminForm1.elements["task"].value = task;
  document.adminForm1.submit();
  return;
}

</script>

<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

$rows = $this->rows;
$pageNav = $this->pageNav;

$_FDR_LANG = $GLOBALS['_FDR_LANG'];


 
?>

<form action="index2.php" method="post" name="adminForm">

		<div id="overDiv" style="position:absolute; visibility:hidden; z-index:10000;"></div>
		<script language="Javascript" src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/overlib_mini.js"></script>
		<script type="text/javascript" src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/mambojavascript.js"></script>
		<script language="Javascript">


		function showNotes(notes, caption) {
				return overlib( notes, STICKY, CAPTION, caption, LEFT, BELOW, WIDTH, 165, OFFSETY, -10, OFFSETX, 56, BGCOLOR, '#d5d5d5', FGCOLOR, '#f1f1f1', CLOSECOLOR, '#000000', CLOSESIZE, '9px' );
		}

		function submitbutton_fastadd_cat() {
			submitbutton('fastadd_cat');
		}
		
		
			function link_listItemTask( id, task ) {
				var f = document.adminForm;
				//alert('id='+id);
				lb = eval( 'f.' + id );
				//alert('lb='+lb);
				if (lb) {
					lb.checked = true;
					submitbutton(task);
				}
				return false;
			}

			function link_isChecked(isitchecked){
				if (isitchecked == true){
					document.adminForm.link_boxchecked.value++;
				}
				else {
					document.adminForm.link_boxchecked.value--;
				}
			}

			function link_checkAll( n ) {
				var f = document.adminForm;
				var c = f.link_toggle.checked;
				var n2 = 0;
				for (i=0; i < n; i++) {
					lb = eval( 'f.lb' + i );
					if (lb) {
						lb.checked = c;
						n2++;
					}
				}
				if (c) {
					document.adminForm.link_boxchecked.value = n2;
				} else {
					document.adminForm.link_boxchecked.value = 0;
				}
			}		
		
			function OrderBy (orderBy, ordering) {
			    
			    document.adminForm.orderBy.value = orderBy;
			    document.adminForm.ordering.value = ordering;
			    document.adminForm.submit();
			    
			}
			
			
			
			
		</script>

<div class="element-box">
<div class="element-pad">
		
<div class="adminlist2" >
		<table>
		    
			<td width="100%" nowrap="nowrap" align="right">
			<b>Search:</b>&nbsp;<input type="text" name="search" value="<?php echo $this->search;?>" class="text_area" onChange="document.adminForm.submit();" />
			</td>
			<td>
				Display&nbsp;<?php echo $pageNav->writeLimitBox(); ?>
			</td>
		</table>		
		
		
					
<table class="adminlist2" width="100%">
<thead width="100%">
<tr>
  <th width="2%" class="title">#</td>
  <th width="3%" class="title" style="text-align: center;"><input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count($rows); ?>);" /></th>
  <th width="30%" nowrap="nowrap" class="title" style="text-align: center;"><?php echo strtoupper('Name (URL)');?><br/><?php echo Recly_HTML::upDownArrows('feed_name', 'feed names', 'com_feederator');?></th>
  <th width="5%" nowrap="nowrap" class="title" style="text-align: center;"><?php echo strtoupper('Published');?></th>
  <th width="15%" nowrap="nowrap" class="title" style="text-align: center;"><?php echo strtoupper('Modified');?><br/><?php echo Recly_HTML::upDownArrows('feed_mofified_date', 'modified dates', 'com_feederator');?></th> 
  <th width="5%" nowrap="nowrap" class="title" style="text-align: center;"><?php echo strtoupper('Id');?><br/><?php echo Recly_HTML::upDownArrows('feed_id', 'ids', 'com_feederator');?></th> 
  <th width="40%" nowrap="nowrap" class="title" style="text-align: center;"><?php echo strtoupper('Details');?></th> 
</tr>
</thead>



<?php
		$k = 0;
		$i = 0;

		foreach ($rows as $row) {
			

			$link = 'index.php?option=com_feederator&amp;task=edit_feed&amp;hidemainmenu=1&amp;id='. $row->Id;
			
			if ( $row->published ) {
				$img = 'tick.png';
				$alt = $_FDR_LANG->PUBLISHED;
				$todo = 'unpublish';
			} else {
				$img = 'publish_x.png';
				$alt = $_FDR_LANG->UNPUBLISHED;
				$todo = 'publish';
			}
			
			$details = '';
			
			//echo "row->internal=";print_r($row->internal);echo "<hr>";

			if ($row->section_based && $row->id_section != '' && $row->id_section != '0') {
			    	$query = "SELECT s.title"
                    	. "\n FROM #__sections AS s"
                    	. "\n WHERE id = '$row->id_section'";
                    $GLOBALS['database']->setQuery( $query );
                    $sectionName = $GLOBALS['database']->loadResult();
			    
			        $details .= '<b>Section</b>: '.$sectionName.' ';
			        
			        if ($row->id_category != '' && $row->id_category != '0') {
			            $details .= '; ';
    			        $query = "SELECT c.title"
                        	. "\n FROM #__categories AS c"
                        	. "\n WHERE id = '$row->id_category'";
                        $GLOBALS['database']->setQuery( $query );
                        $categoryName = $GLOBALS['database']->loadResult();
    			    
    			        $details .= '<b>Category</b>: '.$categoryName.' ';
			        }
			} 			
			
			if ($row->internal == '2' || ($row->internal == '1' && $row->keywords_based && $row->keywords != '')) {  
			        if ($row->id_section != '' && $row->id_section != '0') {
			             $details .= '; ';    
			        }			
    				$details .= '<b>Keywords filter</b>: '.$row->keywords.' ';
			} 

			switch ($row->format) {
			 case 'RSS2.0':
			     $formatImage = "<a href=\"javascript:void(0)\" onClick=\"window.open('".$GLOBALS['mosConfig_live_site'].'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row->Id."','','')\"><img src=\"".$GLOBALS['mosConfig_live_site']."/components/com_feederator/images/rssfeedicon.gif\" alt=\"Click here to view as $row->format\" border=\"0\"></a>";
			 break;
			 
			 case 'iTunesDTD2.0':
			     $formatImage = "<a href=\"javascript:void(0)\" onClick=\"window.open('".$GLOBALS['mosConfig_live_site'].'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row->Id."','','')\"><img src=\"".$GLOBALS['mosConfig_live_site']."/components/com_feederator/images/itunesfeedicon.gif\" alt=\"Click here to view as $row->format\" border=\"0\"></a>";
			 break;			    
			     $formatImage = "(<a href=\"javascript:void(0)\" onClick=\"window.open('".$GLOBALS['mosConfig_live_site'].'/index2.php?option=com_feederator&amp;task=generateRSS&amp;id='.$row->Id."','','')\">$row->format</a>)";
			}
			
		?>	    
		
			<tr class="row<?php echo $k;?>">
			<td style="text-align: center;"><?php echo $i+1+$pageNav->limitstart;?></td>
			<td>
			<input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $row->Id; ?>" onClick="isChecked(this.checked);" /> 
			</td><td>
			
			
			
			<a href="javascript: void(0);"  onClick="return listItemTask('cb<?php echo $i;?>','edit')" title="Edit <?php echo $row->name;?>"><?php echo htmlspecialchars($row->name, ENT_QUOTES);?></a>
 
			&nbsp;<?php echo $formatImage;?>	

			</td>
			<td>
			<center>
			<a href="javascript: void(0);"  onClick="return listItemTask('cb<?php echo $i;?>','<?php echo $todo;?>')">
			<img src="images/<?php echo $img;?>" width="12" height="12" border="0" alt="<?php echo $alt;?>" />
			</center>
			</td>
            <td>
            <center><?php echo $row->modified;?></center>		
			</td>			
            <td>
            <center>
			<?php echo $row->Id;?>
			</center>
			</td>			
			<td>
			<?php
			if ($row->internal == 0) {
			 ?>   
			  <font color="#0000FF"><b><?php echo "<a href=\"javascript:void(0)\" onClick=\"window.open('".$row->url."','','')\" title=\"".$row->url."\">External feed ".substr($row->url,0,50)."</a>";?></b> 
			 <?php 
			}
			if ($row->internal == 2) {
			 ?>   
			  <font color="#00FF00"><b>Compiled feed</b>.&nbsp;  
			 <?php 
			}			
			
			?>
			<?php echo $details;
			if ($row->internal == 0 || $row->internal == 2) {
			 ?>   
			  </font> 
			 <?php 
			}
			?>			
			</td>
			
			</tr>
			<?php 
			$k = 1 - $k;
			 $i++;
		}



		
		?>
			
			<tr>
				<th align="center" colspan="7">&nbsp;</th>
			</tr>
	
			
    <tfoot>
    <td>&nbsp;</td>
	<td align="center" colspan="5"><?php echo $pageNav->writePagesLinks(); ?></td>
	<td><?php echo $pageNav->writePagesCounter(); ?></td>
  
     </tfoot>

</table>
</div>
</div></div>			
	
		<input type="hidden" name="archived" value="<?php echo mosGetParam($_REQUEST, 'archived', 0);?>" />	
		<input type="hidden" name="orderBy" value="<?php echo mosGetParam($_REQUEST, 'orderBy', '');?>" />	
		<input type="hidden" name="ordering" value="<?php echo mosGetParam($_REQUEST, 'ordering', 'ASC');?>" />	
		<input type="hidden" name="publish_up1" value="<?php echo mosGetParam($_REQUEST, 'publish_up1', '');?>" />	
		<input type="hidden" name="publish_down1" value="<?php echo mosGetParam($_REQUEST, 'publish_down1', '');?>" />	
		<input type="hidden" name="filterType" value="<?php echo mosGetParam($_REQUEST, 'filterType', '0');?>" />				
		<input type="hidden" name="option" value="com_feederator" />
		<input type="hidden" name="task" value="list_feeds" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="link_boxchecked" value="0" />
		</form>