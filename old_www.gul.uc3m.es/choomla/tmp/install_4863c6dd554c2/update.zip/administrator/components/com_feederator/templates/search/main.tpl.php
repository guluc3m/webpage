<?php
$searchTerm = $this->search_term;
$searchRequest = $this->search_request;

$pageNav = $this->pageNav;

 $i = 0;
  ?>
  
<form method="post" name="adminForm">  

<input type="hidden" name="limitstart" value="<?php echo $pageNav->limitstart;?>" />
<input type="hidden" name="limit" value="<?php echo $pageNav->limit;?>" />

<table cellpadding="0" cellspacing="0" border="0" width="100%" background="#FF0000">
   
   <tr>
      <td colspan="2">

                       <div class="moduletable">
                       <?php
                       if (sizeof($searchRequest->getKeywords()) == 0) {
                        ?><h3>RSS Feeds</h3>
                        <?php   
                       } else {
                        ?><h3>Total <?php echo number_format(count($this->search_results))?> RSS feeds matching '<?php echo $searchTerm?>' found</h3>
                        <?php
                       }
                       ?> 

                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" background="#00FF00">
<?php
      $exactMatch = 0;
     foreach ($this->search_results as $row) {
     	
?>                                    
                                       <tr>
                                          <td><br />
<?php 
if ('1' == $row['numberOfKeywords'] && '' != $searchTerm) {
      $exactMatch = 1;
}
$this->assign('i', $i);
$this->assign('row', $row);
$this->assign('pageNav', $pageNav);
echo $this->display('search/regular_search_result_item.tpl.php');

?>                                          
                                          </td>
                                       </tr>
<?php
$i++;
      }
      
       
?>                                    
                                    </table>   
<?php
if (count($this->search_results) == 0) {    
 echo "<center><h3>No matches found...</h3>";
 if ($GLOBALS['my']->id >0 ) {
 echo "<b><a href='$this->mosConfig_live_site/index.php?option=com_feederator&amp;task=createFeed'>Click here to add your own feed </a></b></center>";   
 } else {
    echo "<b>Please log in to add your own feed</b></center>";       
 }
} elseif ($exactMatch != '1') {    
     
 if ($GLOBALS['my']->id >0 ) {
 echo "<center>
 <form method='post' action='".sefRelToAbs('index.php?option=com_feederator&amp;task=createFeed')."' name='searchResultsForm'> 
 <input type='submit' value='Add your own feed' class='button'/>
 </form>
 </center>";   
  } else {
    echo "<b>Please log in to add your own feed</b></center>";       
 }       
 
}

?>
              
                       </div>
                        </td>
                     </tr>
            

    <tfoot>
    	<td align="center"><?php echo $pageNav->writePagesLinks(); ?></td>
    	<td><?php echo $pageNav->writePagesCounter(); ?></td>
     </tfoot>      
</table>
<?php 

?>
