<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

function com_uninstall() {
	global $database;

	$msg = '<table width="100%" border="0" cellpadding="8" cellspacing="0"><tr>';
	$msg .= '<td width="100%" align="left" valign="top"><center><h3>Feederator</h3><font class="small">&copy; 2008 Recly Interactive<br/></font></center><br />';

	$msg .= "<fieldset style=\"border: 1px dashed #C0C0C0;\"><legend>Details</legend>";

	$msg .= "<font color=#339900>OK</font> &nbsp; Feederator Uninstalled Successfully</fieldset>";
	$msg .='<br /><br /></td></tr></table>';

	return $msg;
	/*
	
	*/
}
?>
