<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

			    if (is_array($id)) $id = $id[0];  
			     
        		$row = new Recly_RSS('Id','#__fdr_');
        		$krow = new Recly_Keywords('id_rss', 'keyword', '#__fdr_', 'kurss');

        		$row->name = mosGetParam($_REQUEST, 'name', 'not set');     
        		if ($id == '0' || $id == '') $row->published = 1; 
        		$row->internal = mosGetParam($_REQUEST, 'internal', '1');
        		$row->keywords_based = 1;
        		$row->pin = mosGetParam($_REQUEST, 'pin', '0'); 
        		$row->cache = 0; 
        		$row->cache_refresh_time = 3600;
        		
        		if (isset($my) && $my->id != '0') {
        		  $row->created_by = $my->id;
        		  $row->modified_by = $my->id;     
        		}

        		$row->keywords = Recly_Preparator::prepareForSQL(mosGetParam($_REQUEST, 'keywords', '' ));        		

        		$row->format = mosGetParam($_REQUEST, 'format', 'RSS2.0');
        		
        		$row->modified = date("Y-m-d H:i:s", time());
        		
        		
        		if ($id != '' && $id != '0') {
        		    $row->Id = $id;
                    //$row->bindToTable ();   
        		} else { 
        		    $row->created = date("Y-m-d H:i:s", time());   
            		if (isset($my) && $my->id != '0') {
            		  $row->created_by = $my->id;  
            		}        		          
             		$row->_tbl_key = '';
        		}
        				
        		
        		if (!$row->store()) {
        			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
        			echo $row->getError()."<hr>";
        			exit();
        		}        		
        		
        		
     /*   		

        		if ($id != '' && $id != '0') {

                     $row->load( $id );

            		 if (!$row->bind( $_POST )) {
            			echo "<script> alert(['".$row->getError()."'); window.history.go(-1); </script>\n";
            			//echo $row->getError()."<hr>";
            			exit();
            		 }

        		} else {       
    
            		 $row->published = WebVariables::fetchVar('published', 0 );  
            		 $row->id_feedbase = WebVariables::fetchVar('id_feedbase', 1 ); 
            		 $row->name = WebVariables::fetchVar('name', '' ); 
            		 $row->keywords = Preparator::prepareForSQL(WebVariables::fetchVar('keywords', '' )); 
            		 $row->cache = WebVariables::fetchVar('cache', 1 );
            		 $row->cache_refresh_time = WebVariables::fetchVar('cache_refresh_time', 3600 );
            		 $row->_tbl_key = '';
        		}

        		if (!$row->store()) {
        			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
        			echo $row->getError()."<hr>";
        			exit();
        		}	
        		*/
	             /*	$database->setQuery( "SELECT Id"
	            		. "\n FROM #__fdr_feeds"
	            		. "\n WHERE keywords = '$row->keywords' AND name = '$row->name'"
	            	);
	    	       $id = $database->loadResult();    
        	   */
	             
        		$krow->saveKeywords($row->Id, $row->keywords);
        		
        		$msg = $row->name . $_fdr_LANG->SCSA . ' To find out its URL please search for it  ';

        		mosRedirect( "index.php?option=com_feederator&task=list_feeds", $msg );
				
				break;

?>