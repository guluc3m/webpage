<?php

class FDRLanguage {
	
var $ERROR = 'ERROR: ';	
var $YES = 'Yes';	
var $NO = 'No';	
var $CANCEL = 'Cancel';
var $HIDE = 'Hide';
var $SHOW = 'Show';
var $USEGLOBAL = 'Use Global';

var $KEYWORDS = 'Keywords';
var $NAME = 'Name';
var $URL = 'URL';
var $PUBLISHED = 'Published';
var $UNPUBLISHED = 'Unpublished';
var $ID = 'Id';
var $ITEM = 'Item';

var $DOMAIN = 'Domain';

var $ABOUT = 'About';
var $SETTINGS = 'Settings';
var $STATISTICS = 'Statistics';
var $PARAMETERS = 'Parameters';
var $CATEGORIES = 'Categories';
var $MAIN_MENU = 'Main Menu';
var $UPDATE_CLASSES = 'Update Classes';


var $RSS_FEEDS = 'RSS Feeds';
var $ADD_RSS_FEED = 'Add RSS Feed';
var $EDIT_INTERNAL_RSS_FEED = 'Edit Internal RSS Feed';
var $EDIT_EXTERNAL_RSS_FEED = 'Edit External RSS Feed';
var $EDIT_COMPILED_RSS_FEED = 'Edit Compiled RSS Feed';

var $CACHE_ENABLED = 'Cache Enabled';
var $CACHE_TIMEOUT = 'Cache Timeout, sec';
var $MANAGE_FEEDS = 'Manage Feeds';
var $NUMBER_OF_FEEDS = 'Number of Feeds';

var $SELITEM = 'Select an item to';
var $ITEMSP = 'Item(s) successfully published';
var $ITEMSUP = 'Item(s) successfully unpublished';
var $ALLCATS = 'All Categories';
var $TI = 'The item';
var $EAA = ' is currently being edited by another administrator';
var $SCSA = ' successfully Saved';
var $TMSP = 'Text Messaging Service Providers';
var $TMS_P = 'TMS Providers';
var $FCNBD = 'FRONTPAGE COULD NOT BE DELETED';

	
}

$GLOBALS['_FDR_LANG'] = new FDRLanguage();

?>