<?php

defined( '_VALID_MOS' ) or die( 'Restricted access' );

$pageNav = $this->pageNav;

if (sizeof($this->arrayOfElements) > 0) {

  ?>
  
<form method="post" name="adminForm<?php echo !$this->isUrl ? $this->itemExists : '';?>">  

<input type="hidden" name="limitstart<?php echo !$this->isUrl ? $this->itemExists : '';?>" value="<?php echo $pageNav->limitstart;?>" />
<input type="hidden" name="limit<?php echo !$this->isUrl ? $this->itemExists : '';?>" value="<?php echo $pageNav->limit;?>" />
  
  <table cellpadding="0" cellspacing="0" border="0">
  
  <?php
//echo "pageNav=<pre>";print_r($pageNav);echo "</pre><hr>";

$total = ($pageNav->total<$pageNav->limitstart+$pageNav->limit) ? $pageNav->total :$pageNav->limitstart+$pageNav->limit;

//echo "total=<pre>";print_r($total);echo "</pre><hr>";
//exit;
for ($i = $pageNav->limitstart; $i<$total; $i++) {
//foreach ($this->arrayOfElements as $row) {
	       
$row = $this->arrayOfElements[$i];
			$width = 200;
			$height = 20;
			$bgColor = "FFFFFF";

            $link = '';
			
    		if (isset($row['ENCLOSURE|*|URL'])) {			
    			$link = '<OBJECT codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,47,0" WIDTH="'.$width.'" HEIGHT="'.$height.'" bgcolor="#'.$bgColor.'">';
    			$link .='<param name="movie" value="'. $GLOBALS['mosConfig_live_site'] .'/components/com_feederator/includes/swf_player/dewplayer.swf?son=' . $row['ENCLOSURE|*|URL'] . '&autoplay=0&autoreplay=0&bgcolor='.$bgColor.'">';
    			$link .='<PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE='.$bgColor.'>';
    			$link .= '<embed src="'. $GLOBALS['mosConfig_live_site'] .'/components/com_feederator/includes/swf_player/dewplayer.swf?son=' . $row['ENCLOSURE|*|URL'] . '&autoplay=0&autoreplay=0&bgcolor='.$bgColor.'" width="'.$width.'" height="'.$height.'" bgcolor="#'.$bgColor.'" quality="high" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>';
    			$link .= '</OBJECT>';
    		}
?>
<tr>
		<td colspan="2">
										<div id="series_epibox" class="clearfix">
											<span id="dgEpisodes__ctl3_lblIndex"><?php echo $i+1;?>.</span>

											<?php
											if (isset($row['ENCLOSURE|*|URL']) && $row['ENCLOSURE|*|URL'] != '') {?>
											<span class="hlink"><?php echo $row['TITLE'];?></span> &nbsp;&nbsp;												
											<br />											
											<span id="dgEpisodes__ctl3_lblEpiDesc"></span>
											<br />
											<div class="series_episode_table">
												<table width="530px" height="40" border="0" cellspacing="0" cellpadding="0">
													<tr>
														<td><div align="center"><?php echo $link;?>
															</div>
														</td>
														<td><div align="center">
																<a id="dgEpisodes__ctl3_linkDownload" href="<?php echo $row['ENCLOSURE|*|URL'];?>" target="_blank">
																	<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/components/com_feederator/images/download.gif" border="0"/></a>
															</div>
														</td>
														<td><div align="center">
																<span id="dgEpisodes__ctl3_lblEpiDate"><?php echo $row['PUBDATE'];?></span></div>
														</td>
														<td><div align="center">
																<span id="dgEpisodes__ctl3_lblEpiTime"><?php echo $row['ITUNES:DURATION'];?></span></div>
														</td>
														
													</tr>
													<tr>
														<td><div align="center"><span class="text08">Listen</span></div>
														</td>
														<td><div align="center"><span class="text08">Download</span></div>
														</td>
														<td><div align="center"><span class="text08">Episode Date</span></div>
														</td>
														
															<td><div align="center"><span class="text08">Running Time</span></div>
															</td>
														
													</tr>
												</table>
												<br />
												<?php
											} else {
											    ?>
    											<span class="hlink"><a href="<?php echo $row['LINK'];?>"><?php echo $row['TITLE'];?></a></span><br /> 
    											<?php echo $row['PUBDATE'];?><br />	
    											<?php										    
											}
											
											//echo "this->config->get('enableBookmarking')=<pre>";print_r($this->config->get('enableBookmarking'));echo "</pre><hr>";
                                           // echo "row=<pre>";print_r($row);echo "</pre><hr>";

											
												if ($this->config->get('enableBookmarking') && $this->sociotagInstalled) {												    
    												$contentItem = new stdClass();
    												$contentItem->id = $i;
    												$contentItem->introtext = '';
    												if ($row['ENCLOSURE|*|URL'] != '') {
        												$contentItem->fulltext = $row['ITUNES:SUBTITLE'];
        												$contentItem->title = $row['TITLE'];
        												$contentItem->metakey = $row['ITUNES:KEYWORDS'];
        												$contentItem->metadesc = $row['ITUNES:SUBTITLE'];
        												$contentItem->url = $row['ENCLOSURE|*|URL'];
                                                    } else {
                                                        $contentItem->title = $row['TITLE'];
                                                        $contentItem->url = $row['LINK'];
                                                        $contentItem->metadesc = $row['CATEGORY'];
                                                    }
    												$params = null;
    												$page = null;
    												echo sociotag_feederator($contentItem, $params, $page);
												}
												?>
											</div> <!-- end series_episode_table -->
										</div> <!-- end series_epibox -->
										<div class="clearfloats" style="border-bottom: #cccccc 1px solid; margin-bottom:15px; margin-left:15px;"></div>
									</td>
	</tr>

<?php
//$i++;
}
?>
    <tr>
    <td align="center" colspan="2"><center><?php echo $pageNav->writePagesLinks(); ?></center></td>
    	
    </tr>
    <tfoot>
    	<td align="center" colspan="2"><center><?php echo $pageNav->writePagesCounter(); ?></center></td>  	
    	
     </tfoot>
     
     
</table>
<?php
//echo $paginator->build($this);
}
?>

</form>
</div>


